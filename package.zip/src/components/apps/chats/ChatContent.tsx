import React, { useContext, useEffect, useRef, useState } from 'react';
import DOMPurify from 'dompurify';
import {
  Typography,
  Divider,
  Avatar,
  ListItem,
  ListItemText,
  ListItemAvatar,
  IconButton,
  Box,
  Stack,
  Badge,
  useMediaQuery,
  Theme
} from '@mui/material';
import { IconArrowBarToDown, IconDotsVertical, IconMenu2, IconMessageReply, IconPhone, IconVideo } from '@tabler/icons-react';
import { formatDistanceToNowStrict } from 'date-fns';
import ChatInsideSidebar from './ChatInsideSidebar';
import { ChatContext } from "src/context/ChatContext";
import { ChatMessage, ChatsType } from 'src/types/apps/chat';
import formatToRussianDate, { formatToRussianDateSmart } from 'src/help-functions/format-to-date';
import SimpleBar from 'simplebar-react';
import { uniqueId } from 'lodash';
import { ReplyAll, ReplyAllRounded, ReplyAllSharp } from '@mui/icons-material';


const ChatContent: React.FC = () => {
  const [open, setOpen] = React.useState(true);
  const lgUp = useMediaQuery((theme: Theme) => theme.breakpoints.up("lg"));

  const {selectedChat} = useContext(ChatContext);

  const mainBoxRef = useRef<HTMLElement>(null);
  const inBoxRef = useRef<HTMLElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setTimeout(() => {
      if (messagesEndRef.current) {
        messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
      }
    }, 1000);
    
  }, []);
  


  // console.log(selectedChat?.id, selectedChat?.messages[selectedChat?.messages.length - 1], 'ffffffffffffffffffffffffffffffffffff');

  return selectedChat ? (
    <SimpleBar>
      <Box sx={{display: 'flex', flexWrap: 'wrap'}}>
        {selectedChat ? (
          <Box width={'100%'}> 
            {/* ------------------------------------------- */}
            {/* Header Part */}
            {/* ------------------------------------------- */}
            <Box>
              <Box display="flex" alignItems="center" p={2}>
                <Box
                  sx={{
                    display: { xs: "block", md: "block", lg: "block" },
                    mr: "10px",
                  }}
                >
                  {/* <IconMenu2 stroke={1.5} onClick={toggleChatSidebar} /> */}
                </Box>
                <ListItem key={selectedChat.name} dense disableGutters>
                  <ListItemAvatar>
                    <Badge
                      color={
                        selectedChat.status === "online"
                          ? "success"
                          : selectedChat.status === "busy"
                            ? "error"
                            : selectedChat.status === "away"
                              ? "warning"
                              : "secondary"
                      }
                      variant="dot"
                      anchorOrigin={{
                        vertical: "bottom",
                        horizontal: "right",
                      }}
                      overlap="circular"
                    >
                      <Avatar alt={selectedChat.name} src={selectedChat.thumb} sx={{ width: 40, height: 40 }} />
                    </Badge>
                  </ListItemAvatar>
                  <ListItemText
                    primary={
                      <Typography variant="h5">{selectedChat.name}</Typography>
                    }
                    secondary={selectedChat.status}
                  />
                </ListItem>
                {/* <Stack direction={"row"}>
                  <IconButton aria-label="phone">
                    <IconPhone stroke={1.5} />
                  </IconButton>
                  <IconButton aria-label="video">
                    <IconVideo stroke={1.5} />
                  </IconButton>
                  <IconButton aria-label="sidebar" onClick={() => setOpen(!open)}>
                    <IconDotsVertical stroke={1.5} />
                  </IconButton>
                </Stack> */}
              </Box>
              <Divider />
            </Box>
            {/* ------------------------------------------- */}
            {/* Chat Content */}
            {/* ------------------------------------------- */}

            <Box sx={{display: 'flex', width: 'auto', overflow: 'auto'}} ref={mainBoxRef}>
              {/* ------------------------------------------- */}
              {/* Chat msges */}
              {/* ------------------------------------------- */}

              <Box>
                <Box
                  sx={{
                    height: "650px",
                    overflow: "auto",
                    maxHeight: "800px",
                    width: mainBoxRef && inBoxRef && ((mainBoxRef.current?.clientWidth || 0) - (inBoxRef.current?.clientWidth || 0)) > 300 ?
                     `${((mainBoxRef.current?.clientWidth || 0) - (inBoxRef.current?.clientWidth || 0))}px` : '300px',
                  }}
                >
                  <Box p={3}>
                    {selectedChat.messages?.length > 0 && selectedChat.messages.map((chat: any, index: number) => {
                      const cleaned = chat.msg
                      .replace(/Сообщение от .*?:/, "")
                      .replace(/<br\/><br\/>/g, "")
                      .trim();
                      const safeHtml = DOMPurify.sanitize(cleaned);

                      const commentsHTML = chat?.comments.map((comment: any) => DOMPurify.sanitize(comment.body))

                      // console.log(chat.msg, cleaned);
                      return (
                        <Box key={index + chat.createdAt}>
                          {selectedChat.id === chat.senderId ? (
                            <Box display="flex">
                              <ListItemAvatar>
                                <Avatar
                                  alt={selectedChat.name}
                                  src={selectedChat.thumb}
                                  sx={{ width: 40, height: 40 }}
                                />
                              </ListItemAvatar>
                              <Box>
                                {chat.createdAt ? (
                                  <Typography
                                    variant="body2"
                                    color="grey.400"
                                    mb={1}
                                  >
                                    {selectedChat.name},{" "}
                                    {formatToRussianDateSmart(
                                      new Date(chat.createdAt)
                                    )}{" "}
                                  </Typography>
                                ) : null}
                                {chat.type === "text" ? (
                                  <Box>
                                  <Box
                                    mb={2}
                                    sx={{
                                      p: 1,
                                      backgroundColor: "grey.100",
                                      mr: "auto",
                                      maxWidth: "320px",
                                    }}
                                    dangerouslySetInnerHTML={{ __html: safeHtml }}
                                  />
                                  
                                  {/* Комментарии */}
                                  {chat.comments.length > 0 && commentsHTML.map((commentHTML: any) => (
                                    <Box sx={{ position: 'relative', marginRight: 4, mb: 2 }}>
                                    
                                    <Box
                                      sx={{
                                        backgroundColor: "#d4eaff",
                                        padding: '1px 10px',
                                        maxWidth: "320px",
                                        wordBreak: 'break-word',
                                      }}
                                      dangerouslySetInnerHTML={{ __html: commentHTML }}
                                    />
                                    <ReplyAllRounded
                                      fontSize="medium"
                                      sx={{
                                        position: 'absolute',
                                        right: '-30px',
                                        top: '50%',
                                        transform: 'translateY(-50%)', // <-- центрируем по вертикали
                                        color: "primary.main"
                                      }}
                                    />
                                  </Box>
                                  
                                  ))}
                                </Box>
                                
                                ) : null}
                                {chat.type === "image" ? (
                                  <Box
                                    mb={1}
                                    sx={{
                                      overflow: "hidden",
                                      lineHeight: "0px",
                                    }}
                                  >
                                    <img
                                      src={chat.msg}
                                      alt="attach"
                                      width="150" height="150"
                                    />
                                  </Box>
                                ) : null}
                              </Box>
                            </Box>
                          ) : (
                            <Box
                              mb={1}
                              display="flex"
                              alignItems="flex-end"
                              flexDirection="row-reverse"
                            >
                              <Box
                                alignItems="flex-end"
                                display="flex"
                                flexDirection={"column"}
                              >
                                {chat.createdAt ? (
                                  <Typography
                                    variant="body2"
                                    color="grey.400"
                                    mb={1}
                                  >
                                    {formatToRussianDateSmart(
                                      new Date(chat.createdAt)
                                    )}{" "}
                                  </Typography>
                                ) : null}
                                {chat.type === "text" ? (
                                  <Box>
                                    <Box
                                      mb={1}
                                      sx={{
                                        p: 1,
                                        backgroundColor: "primary.light",
                                        ml: "auto",
                                        maxWidth: "320px",
                                      }}
                                      dangerouslySetInnerHTML={{ __html: safeHtml }}
                                    >
                                    </Box>
                                    {chat.comments.length > 0 && commentsHTML.map((commentHTML: any) => (
                                    <Box sx={{ position: 'relative', ml: 4, mb: 2 }}>
                                    <ReplyAllRounded
                                      fontSize="medium"
                                      sx={{
                                        position: 'absolute',
                                        left: '-30px',
                                        top: '50%',
                                        transform: 'translateY(-50%) rotate3d(0, 1, 0, 180deg)', // <-- центрируем по вертикали
                                        color: "primary.main"
                                      }}
                                    />
                                    <Box
                                      sx={{
                                        backgroundColor: "#d4eaff",
                                        padding: '1px 10px',
                                        maxWidth: "320px",
                                        wordBreak: 'break-word',
                                      }}
                                      dangerouslySetInnerHTML={{ __html: commentHTML }}
                                    />
                                  </Box>
                                  
                                  ))}
                                    
                                  </Box>
                                ) : null}
                                {chat.type === "image" ? (
                                  <Box
                                    mb={1}
                                    sx={{ overflow: "hidden", lineHeight: "0px" }}
                                  >
                                    <img
                                      src={chat.msg}
                                      alt="attach"
                                      width="250" height="165"
                                    />
                                  </Box>
                                ) : null}
                              </Box>
                            </Box>
                          )}
                        </Box>
                      );
                    })}
                    <div ref={messagesEndRef} />
                  </Box>
                </Box>
              </Box>

              {/* ------------------------------------------- */}
              {/* Chat right sidebar Content */}
              {/* ------------------------------------------- */}
              {open ? (
                <Box display="flex" flexShrink="0px" ref={inBoxRef}>
                  <ChatInsideSidebar
                    isInSidebar={lgUp ? open : open}
                    chat={selectedChat}
                  />
                </Box>
              ) : (
                ""
              )}
            </Box>
          </Box>
        ) : (
          <Box display="flex" alignItems="center" p={2} pb={1} pt={1}>
            {/* ------------------------------------------- */}
            {/* if No Chat Content */}
            {/* ------------------------------------------- */}
            <Box
              sx={{
                display: { xs: "flex", md: "flex", lg: "flex" },  
                mr: "10px",
              }}
            >
              <IconMenu2 stroke={1.5} />
            </Box>
            <Typography variant="h4">Select Chat</Typography>
          </Box>
        )}
      </Box>
    </SimpleBar>
  ): <></>;
};

export default React.memo(ChatContent);

