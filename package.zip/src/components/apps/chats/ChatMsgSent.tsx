import React, { useContext, useState } from "react";
import Box from "@mui/material/Box";
import IconButton from "@mui/material/IconButton";
import InputBase from "@mui/material/InputBase";

import { IconPaperclip, IconPhoto, IconSend } from "@tabler/icons-react";
import { ChatContext } from "src/context/ChatContext";
import { sendPushFromClient } from "src/utils/pushManager";
import { ChatsType } from "src/types/apps/chat";
import { useAppDispatch, useAppSelector } from "src/store/hooks";
import { sendMessage as sendElmaMessage } from "src/store/middleware/thunks";
import { selectClientName } from "src/store/selectors/authSelector";

type ChatMsgSentProps = {
  currentChat: ChatsType | null;
  updateChat: (chat: ChatsType | null) => void;
};

const ChatMsgSent = ({ currentChat, updateChat }: ChatMsgSentProps) => {
  const dispatch = useAppDispatch();
  const clientName = useAppSelector(selectClientName);
  const { selectedChat } = useContext(ChatContext);

  const [msg, setMsg] = useState("");

  const handleChatMsgChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setMsg(e.target.value);
  };

  const handleSendMessage = () => {
    if (!msg.trim()) return;

    const chatId = selectedChat?.taskId || currentChat?.taskId || "";
    const orderNumber = selectedChat?.name || currentChat?.name || "";

    sendPushFromClient(msg, `Заказ - ${orderNumber}`);
    dispatch(sendElmaMessage({ id: chatId, text: msg, orderNumber }));

    if (currentChat) {
      const updatedMessages = [...currentChat.messages];
      updatedMessages.push({
        ...updatedMessages[updatedMessages.length - 1],
        id: String(Math.random()),
        createdAt: new Date(),
        msg,
        senderId: 0,
      });
      const updatedChat = { ...currentChat, messages: updatedMessages };
      updateChat(updatedChat);
    }

    setMsg("");
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <Box p={2}>
      <Box display="flex" gap="10px" alignItems="center">
        <InputBase
          id="msg-sent"
          fullWidth
          value={msg}
          placeholder="Ваше сообщение"
          size="small"
          type="text"
          inputProps={{ "aria-label": "Ваше сообщение" }}
          onChange={handleChatMsgChange}
          onKeyDown={handleKeyPress} // 🔥 Тут ловим Enter
        />
        <IconButton
          aria-label="send"
          onClick={handleSendMessage}
          disabled={!msg.trim()}
          color="primary"
        >
          <IconSend stroke={1.5} size="20" />
        </IconButton>
        <IconButton aria-label="photo">
          <IconPhoto stroke={1.5} size="20" />
        </IconButton>
        <IconButton aria-label="attach">
          <IconPaperclip stroke={1.5} size="20" />
        </IconButton>
      </Box>
    </Box>
  );
};

export default ChatMsgSent;
