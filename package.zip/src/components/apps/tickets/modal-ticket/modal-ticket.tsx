import { Avatar, Button, Dialog, DialogContent, DialogTitle, Divider, IconButton, ListItemAvatar, TextareaAutosize, TextField, Tooltip, Typography } from "@mui/material"
import { Box, Grid, styled, useTheme } from "@mui/system"
import React, { useContext, useEffect, useRef, useState } from "react"
import CustomFormLabel from "src/components/forms/theme-elements/CustomFormLabel"
import CustomTextField from "src/components/forms/theme-elements/CustomTextField"
import { ELMATicket } from "src/mocks/tickets/ticket.type"
import { AllStatus, getStatus } from "../TicketListing"
import { IconMessage, IconPlus } from "@tabler/icons-react"
import { useNavigate } from "react-router"
import { ChatContext, ChatProvider } from "src/context/ChatContext"
import { formatDistanceToNowStrict } from "date-fns"
import AppCard from "src/components/shared/AppCard"
import ChatContent from "../../chats/ChatContent"
import ChatMsgSent from "../../chats/ChatMsgSent"
import MiniChat from "../mini-chat/mini-chat"
import { ChatsType } from "src/types/apps/chat"
import ModalDetails from "./modal-datails/modal-details"
import { sendPushFromClient } from "src/utils/pushManager"
import { useAppDispatch, useAppSelector } from "src/store/hooks"
import { fetchAddNewOrder, fetchMessages } from "src/store/middleware/thunks"
import { addNEwTicket } from "src/store/slices/ticketsSlice"
import { selectMessages } from "src/store/selectors/messagesSelectors"

type ModalTicketProps = {
    show: boolean,
    close: (isOpen: boolean) => void,
    ticket: ELMATicket,
}

const ModalTicket = (props: ModalTicketProps) => {
  const [images, setImages] = useState<File[]>([]);

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      setImages([...images, ...Array.from(event.target.files)]);
    }
  };

  const handleClearImages = () => {
    setImages([]);
  };
  
    const dispatch = useAppDispatch();

    const {show, close, ticket} = props;
    const textRef = useRef<HTMLTextAreaElement>(null);

    const currentChats: any  = useAppSelector(selectMessages);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
      const fetchChats = async () => {
        if (!ticket?.__id) return;
        try {
          dispatch(fetchMessages(ticket.__id));
        } catch (err) {
          console.error('Ошибка при загрузке чатов', err);
        } finally {
          setIsLoading(false);
        }
      };

      fetchChats();
    }, [ticket?.__id]);

    const selectedChat: ChatsType = {
      id: ticket?.__id ?? '',
      taskId: ticket?.__id || '',
      name: ticket?.nomer_zakaza || '',
      status: 'UPLOAD',
      recent: true,
      excerpt: '',
      chatHistory: [],
      messages: currentChats,
    };

    const [isMobileSidebarOpen, setMobileSidebarOpen] = useState(false);

    const navigate = useNavigate();

    const theme = useTheme();

    const IconButtonStyled = styled(IconButton)(() => ({
        padding: '5px 10px',
        gap: '10px',
        borderRadius: `${10}px`,
        marginBottom: '0px',
        color: `white !important`,
        backgroundColor: theme.palette.primary.main,
        '&:hover': {
          backgroundColor: theme.palette.primary.light,
        },
      }));

    type GetTicketFieldType = {
      ticket: ELMATicket;
    }

    const GetTicketFields = (props: GetTicketFieldType) => {
      const {ticket} = props;
      const status = getStatus(ticket);

      switch(status) {
        case AllStatus.NEW:
          return(
            <React.Fragment>
              <Typography mt={0} variant="caption">{ticket.zapros}</Typography><br />
            </React.Fragment>
          )
        case AllStatus.PENDING:
          return(
            <React.Fragment>
              <Typography mt={0} variant="caption">{ticket.zapros}</Typography><br />
              <br/>
              <Typography mt={0} fontWeight={600}>Маршрут и стоимость: <Typography mt={0} variant="caption">{ticket.otvet_klientu}</Typography></Typography>
            </React.Fragment>
          )
        case AllStatus.BOOKED:
        case AllStatus.FORMED:
        case AllStatus.CLOSED:
          return(
            <React.Fragment>
              <Typography mt={0} variant="caption">{ticket.zapros}</Typography><br />
              <br/>
              <Typography mt={0} fontWeight={600}>ФИО КЛИЕНТОВ: <Typography mt={0} variant="caption"> NAME LASTNAME</Typography></Typography>
              <br/>
              <Typography mt={0} fontWeight={600}>НОМЕР ПАСПОРТА:<Typography mt={0} variant="caption"> XXXXXX</Typography></Typography>
              <br/>
              <Typography mt={0} fontWeight={600}>Маршрут и стоимость:<Typography mt={0} variant="caption"> {ticket.otvet_klientu}</Typography></Typography>
              <br/>
              {ticket.itogovaya_stoimost && (
                <Typography mt={0} fontWeight={600}>Итоговая стоимость:<Typography mt={0} variant="caption"> {ticket.itogovaya_stoimost.cents}</Typography></Typography>
              )}
              <br/>
              {(status === AllStatus.FORMED || status === AllStatus.CLOSED) && (
                <Typography mt={0} fontWeight={600}>Маршрутная квитанция:<Typography mt={0} variant="caption"> ФАЙЛ.txt</Typography></Typography>
              )}
              <br/>
              {ticket.taim_limit && (
                <Typography mt={0} fontWeight={600}>Тайм-лимит<Typography mt={0} variant="caption"> {ticket.taim_limit}</Typography></Typography>
              )}
              {ticket.otvet_klientu3 && <Typography mt={0} variant="caption"> {ticket.otvet_klientu3}</Typography>}
            </React.Fragment>
          )
      }
    } 

    const handlerOnClickAdd = () => {
      if (textRef) {
        // const newTicket = structuredClone(ticket);
        // newTicket.zapros = textRef?.current?.value ?? '';
        // newTicket.__updatedBy = null;
        // newTicket.__createdAt = String(new Date());
        // newTicket.__id = String(Math.random());
        // newTicket.otvet_klientu = null;
        // newTicket.otvet_klientu1 = null;
        // newTicket.otvet_klientu3 = null;
        // newTicket.taim_limit = null;
        // if (newTicket.__status?.status) {
        //   newTicket.__status.status = 1;
        // }
        // dispatch(addNEwTicket(newTicket));
        close(false);
      }
    }

    return (
        <Dialog
          open={show}
          onClose={() => close(false)}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
          PaperProps={{ component: "form" }}
          className="dialog-container"
        >
          <DialogContent sx={{
            width: `${window.innerWidth * (ticket?.zapros ? 0.85 : window.innerWidth > 500 ? 0.4 : 0.85)}px`}}>
            <Grid container spacing={3}>
              <Grid size={{ xs: 12, sm: 12 }}>
                {ticket?.zapros ? <ModalDetails ticket={ticket} onClose={() => close(false)}/> : <Box>
                  <Box>
                    <Typography mb={1}>Текст запроса:</Typography>
                    <TextField multiline inputRef={textRef} fullWidth sx={{'& textarea': { padding: 0 }}}></TextField>
                  </Box>
                  {/* Загрузка фото */}
                  <Box mt={3}>
                    <Typography mb={1}>Фотографии:</Typography>
                    <Button
                      variant="contained"
                      component="label"
                      fullWidth
                    >
                      Загрузить фотографии
                      <input
                        hidden
                        accept="image/*"
                        multiple
                        type="file"
                        onChange={handleImageChange}
                      />
                    </Button>

                    {/* Превью */}
                    <Box mt={2} sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                      {images.map((file, idx) => (
                        <Box key={idx} sx={{ position: 'relative' }}>
                          <img
                            src={URL.createObjectURL(file)}
                            alt={`preview-${idx}`}
                            width={100}
                            height={100}
                            style={{ objectFit: 'cover', borderRadius: 8, border: '1px solid #ccc' }}
                          />
                        </Box>
                      ))}
                    </Box>

                        {images.length > 0 && (
                          <Box mt={1}>
                            <Button color="error" onClick={handleClearImages}>
                              Удалить все фотографии
                            </Button>
                          </Box>
                        )}
                </Box>
                <Box mt={3} pt={2}>
                <IconButtonStyled
  sx={{ width: '100%' }}
  onClick={() => {
    dispatch(fetchAddNewOrder({
      zapros: textRef?.current?.value ?? '',
      imgs: images
    }));
    handlerOnClickAdd();
    sendPushFromClient('На рассмотрении', `Создан новый заказ ${selectedChat?.name}`);
  }}
>
  <IconPlus size="22" color="white" /> {/* <-- явно указываем цвет */}
  <Typography variant="button" sx={{ color: 'white' }}>
    СОЗДАТЬ
  </Typography>
</IconButtonStyled>

  </Box>
                </Box>}
              </Grid>
            </Grid>
            </DialogContent>
        </Dialog>
    )
}

export default ModalTicket;