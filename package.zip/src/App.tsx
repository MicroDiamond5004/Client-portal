import { CssBaseline, ThemeProvider } from '@mui/material';
import { ThemeSettings } from './theme/Theme';
import RTL from './layouts/full/shared/customizer/RTL';
import { BrowserRouter, RouterProvider, useLocation, useNavigate } from 'react-router';
import router from './routes/Router';
import { CustomizerContext } from 'src/context/CustomizerContext';
import { useContext, useEffect } from 'react';
import PushManagerComponent from './utils/pushSubscribe';
import AppRoutes from './routes/Router';


function App() {

  const theme = ThemeSettings();
  const { activeDir } = useContext(CustomizerContext);
  
  useEffect(() => {
    if (typeof Notification !== 'undefined' && Notification.permission === 'default') {
      Notification.requestPermission().catch((e) =>
        console.warn('❗Ошибка при запросе разрешения на уведомления:', e)
      );
    }
  }, []);   

  return (
    <ThemeProvider theme={theme}>
    <PushManagerComponent />
    <RTL direction={activeDir}>
      <CssBaseline />
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </RTL>
  </ThemeProvider>
  );
}

export default App;
