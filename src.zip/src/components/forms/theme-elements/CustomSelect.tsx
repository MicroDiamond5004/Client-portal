'use client'

import { styled } from '@mui/material/styles';
import { Select } from '@mui/material';

const CustomSelect = styled((props: any) => <Select {...props} />)(({ }) => ({}));

export default CustomSelect;
