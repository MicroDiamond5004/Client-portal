import { Paper, Typography } from '@mui/material';
import { Box } from '@mui/system';
import React, { useEffect, useState } from 'react';
import api from 'src/store/api';
import { FileListBlock } from '../fileList/FileListBlock';

type VipServiceBlockProps = {
  ticket: any;
};

export const VipServiceBlock: React.FC<VipServiceBlockProps> = ({ ticket }) => {
  const [files, setFiles] = useState<any[]>([]);
  const originalFiles = ticket.vip_uslugi_f ?? [];

  useEffect(() => {
    const fetchFiles = async () => {
      if (originalFiles.length > 0) {
        const response = await api.post('/get-files', {
          fileIds: originalFiles.map((file: any) => file.__id),
        });

        if (response.data.success) {
          setFiles(response.data.files);
        } else {
          console.error('Ошибка при загрузке файлов VipServiceBlock:', response.data.error);
        }
      }
    };

    fetchFiles();
  }, [originalFiles]);

  const description = ticket.opisanie_uslug;

  if (!description && files.length === 0) {
    return (
      <Paper sx={{ p: 3, my: 2, borderRadius: 2, backgroundColor: '#f9f9f9' }}>
        <Typography>Нет данных по VIP-услугам</Typography>
      </Paper>
    );
  }

  return (
    <Box>
      <Paper sx={{ p: 3, my: 2, borderRadius: 2, backgroundColor: '#f9f9f9' }}>
        <Typography variant="h5" mb={2}>VIP-услуги</Typography>
        {description && (
          <Typography mb={1}><strong>Описание:</strong> {description}</Typography>
        )}
        {files.length > 0 && (
          <FileListBlock
            title="Файлы VIP-услуг"
            files={files}
            originalFiles={originalFiles}
          />
        )}
      </Paper>
    </Box>
  );
};
