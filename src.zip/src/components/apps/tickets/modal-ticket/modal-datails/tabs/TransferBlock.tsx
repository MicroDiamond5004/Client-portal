import { Paper, Typography } from '@mui/material';
import { Box } from '@mui/system';
import React, { useEffect, useState } from 'react';
import api from 'src/store/api';
import { FileListBlock } from '../fileList/FileListBlock';

type TransferBlockProps = {
  ticket: any;
};

export const TransferBlock: React.FC<TransferBlockProps> = ({ ticket }) => {
  const [files, setFiles] = useState<any[]>([]);
  const originalFiles = ticket.transfer_f ?? [];

  useEffect(() => {
    const fetchFiles = async () => {
      if (originalFiles.length > 0) {
        const response = await api.post('/get-files', {
          fileIds: originalFiles.map((file: any) => file.__id),
        });

        if (response.data.success) {
          setFiles(response.data.files);
        } else {
          console.error('Ошибка при загрузке файлов TransferBlock:', response.data.error);
        }
      }
    };

    fetchFiles();
  }, [originalFiles]);

  const description = ticket.opisanie_transfera;

  if (!description && files.length === 0) {
    return (
      <Paper sx={{ p: 3, my: 2, borderRadius: 2, backgroundColor: '#f9f9f9' }}>
        <Typography>Нет данных по трансферу</Typography>
      </Paper>
    );
  }

  return (
    <Box>
      <Paper sx={{ p: 3, my: 2, borderRadius: 2, backgroundColor: '#f9f9f9' }}>
        <Typography variant="h5" mb={2}>Трансфер</Typography>
        {description && (
          <Typography mb={1}><strong>Описание:</strong> {description}</Typography>
        )}
        {files.length > 0 && (
          <FileListBlock
            title="Файлы трансфера"
            files={files}
            originalFiles={originalFiles}
          />
        )}
      </Paper>
    </Box>
  );
};
