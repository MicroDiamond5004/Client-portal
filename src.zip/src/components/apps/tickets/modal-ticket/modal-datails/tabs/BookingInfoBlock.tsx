import { Paper, Typography } from '@mui/material';
import { Box } from '@mui/system';
import React from 'react';
import formatToRussianDate from 'src/help-functions/format-to-date';

type BookingInfoBlockProps = {
  bookingNumber: number;
  ticket: any;
  passports?: Record<string, [string | undefined, string | undefined]>;
};

export const BookingInfoBlock: React.FC<BookingInfoBlockProps> = ({
  bookingNumber,
  ticket,
  passports,
}) => {
  const suffix = bookingNumber === 1 ? '' : `_bron_${bookingNumber}`;

  const passportNumber = ticket[`nomer_a_pasporta_ov_dlya_proverki${suffix}`];
  const fioIds =
    bookingNumber === 1
      ? ticket['fio2']
      : bookingNumber === 2
        ? ticket['dopolnitelnye_fio']
        : ticket[`fio_passazhira_ov${suffix}`];
  const route =
    ticket[`otvet_klientu_o_bronirovanii${suffix}`] ??
    ticket?.otvet_klientu3 ??
    ticket?.otvet_klientu ??
    ticket?.otvet_klientu1;
  const timeLimit = ticket[`taim_limit_dlya_klienta${suffix}`];
  const preAnswer = ticket[`otvet_klientu3${suffix}`];
  const bookingCode =
    ticket[`kod_bronirovaniya_v_sisteme${suffix}`] ?? ticket[`dopolnitelnyi_kod_bronirovaniya`];

  const fullNames =
    Array.isArray(fioIds) && passports
      ? fioIds
          .map((id: string) => passports[id]?.[0])
          .filter(Boolean)
          .join(', ')
      : '';

  const hasData =
    passportNumber ||
    (fioIds?.length > 0) ||
    route ||
    timeLimit ||
    preAnswer ||
    bookingCode ||
    fullNames;

  if (!hasData) {
    return (
      <Paper sx={{ p: 3, my: 2, borderRadius: 2, backgroundColor: '#f9f9f9' }}>
        <Typography>Нет данных по брони №{bookingNumber}</Typography>
      </Paper>
    );
  }

  return (
    <Paper
      elevation={3}
      sx={{ p: 3, my: 2, borderRadius: 2, backgroundColor: '#f9f9f9' }}
    >
      <Typography variant="h5" mb={2}>Бронь №{bookingNumber}</Typography>

      {fullNames && (
        <Typography mb={1}>
          <strong>Пассажир(ы):</strong> {fullNames}
        </Typography>
      )}

      {passportNumber && (
        <>
          <Typography fontWeight={600}>Номер паспорта для проверки:</Typography>
          {Array.isArray(passportNumber) ? (
            passportNumber.map((id: any) => (
              <Typography
                key={id}
                mb={1}
                sx={{ wordBreak: 'break-word', whiteSpace: 'pre-wrap', overflowWrap: 'break-word' }}
              >
                {passports?.[id]?.[0]} - {passports?.[id]?.[1]}
              </Typography>
            ))
          ) : (
            <Typography mb={1}>{passportNumber}</Typography>
          )}
        </>
      )}

      {route && (
        <Typography mb={1}>
          <strong>Маршрут:</strong>
          {route
            .split('✈️')
            .filter(Boolean)
            .map((part: string, idx: number) => (
              <React.Fragment key={idx}>
                <br />
                ✈️ {part.trim().split('\n').map((line, i) => (
                  <React.Fragment key={i}>
                    {line}
                    {i < part.split('\n').length - 1 && <br />}
                  </React.Fragment>
                ))}
              </React.Fragment>
            ))}
        </Typography>
      )}

      {timeLimit && (
        <Typography mb={1}>
          <strong>Тайм-лимит:</strong> До {formatToRussianDate(timeLimit)}
        </Typography>
      )}

      {preAnswer && (
        <Typography mb={1}>
          <strong>Ответ перед оформлением:</strong> {preAnswer}
        </Typography>
      )}

      {bookingCode && (
        <Typography>
          <strong>Код бронирования:</strong> {bookingCode}
        </Typography>
      )}
    </Paper>
  );
};
