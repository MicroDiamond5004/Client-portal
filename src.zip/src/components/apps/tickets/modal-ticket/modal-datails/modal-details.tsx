import PageContainer from 'src/components/container/PageContainer';
import { InvoiceProvider } from 'src/context/InvoiceContext/index';
import InvoiceDetail from 'src/components/apps/invoice/Invoice-detail/index';
import BlankCard from 'src/components/shared/BlankCard';
import { Accordion, AccordionDetails, AccordionSummary, Avatar, CardContent, IconButton, Tab, Tabs } from '@mui/material';
import {
  Typography,
  Button,
  Paper,
  Box,
  Stack,
  Chip,
  Divider,
  Grid,
} from '@mui/material';
import { Link } from 'react-router';
import Logo from 'src/layouts/full/shared/logo/Logo';
import { ELMATicket } from 'src/mocks/tickets/ticket.type';
import { AllStatus, getStatus } from '../../TicketListing';
import formatToRussianDate from 'src/help-functions/format-to-date';
import MiniChat from '../../mini-chat/mini-chat';
import React, { useEffect, useState } from 'react';
import { ChatsType } from 'src/types/apps/chat';
import { useAppDispatch, useAppSelector } from 'src/store/hooks';
import { fetchMessages } from 'src/store/middleware/thunks';
import { selectMessages } from 'src/store/selectors/messagesSelectors';
import { selectPassports } from 'src/store/selectors/ticketsSelectors';
import { IconDownload, IconEye, IconFile } from '@tabler/icons-react';
import { DialogViewer } from 'src/components/apps/chats/ChatInsideSidebar';
import api from 'src/store/api';
import { useMediaQuery, useTheme, width } from '@mui/system';
import { showFilePreview } from 'src/store/slices/filePreviewSlice';
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { HotelsBlock } from './tabs/HotelsBlock';
import { TransferBlock } from './tabs/TransferBlock';
import { VipServiceBlock } from './tabs/VipServiceBlock';
import { MapBlock } from './tabs/MapBlock';
import { BookingInfoBlock } from './tabs/BookingInfoBlock';

type ModalTicketProps = {
    ticket: ELMATicket;
    
    onClose: () => void;
}

const ModalDetails = (props: ModalTicketProps) => {
    const { ticket, onClose } = props;

    const dispatch = useAppDispatch();
  
    const currentChats: any = useAppSelector(selectMessages);
    const passports = useAppSelector(selectPassports)

    const [isLoading, setIsLoading] = useState(true); // если нужно знать статус
    const [tabIndex, setTabIndex] = useState(0);

    const [openViewer, setOpenViewer] = useState(false);
    const [pdfBlobUrl, setPdfBlobUrl] = useState<string | null>(null);
    const [pageNumber, setPageNumber] = useState(1);
    const [numPages, setNumPages] = useState<number>(0);
    const [error, setError] = useState(null);
    const [loading, setLoading] = useState(false);

    const [zaprosFiles, setZaprosFiles] = useState<any[]>([]);
    const [files, setFiles] = useState<any[]>([]);

    const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  
    const handleViewFile = async (file: any) => {
        try {
          setLoading(true);
          // console.log('Загрузка файла...');
          const response = await fetch(file.url, { method: 'GET' });
    
          if (!response.ok) {
            throw new Error('Не удалось загрузить файл');
          }
          
          const blob = await response.blob();
          const contentType = blob.type;
          if (contentType !== 'application/pdf') {
            throw new Error('Файл не является PDF');
          }
          
          const blobUrl = URL.createObjectURL(blob);
          // console.log('Blob URL:', blobUrl); // Логируем URL
          setPdfBlobUrl(blobUrl);      
          setOpenViewer(true); // Открываем просмотрщик
          setError(null); // Очистка ошибки
        } catch (error: any) {
          console.error('Ошибка при загрузке файла:', error);
          setError(error); // Сохраняем ошибку для отображения
        } finally {
          setLoading(false);
        }
      };
      

      const handleDownloadFile = (file: any) => {
        const link = document.createElement('a');
        link.href = file.url;
        link.download = decodeURIComponent(file.filename); // исправляем имя файла
        link.click();
      };
    
      const handleCloseViewer = () => {
        setOpenViewer(false);
        if (pdfBlobUrl) {
          URL.revokeObjectURL(pdfBlobUrl); // Отзываем URL
          setPdfBlobUrl(null); // Сбрасываем ссылку
        }
      };

    useEffect(() => {
      const fetchFiles = async () => {
        try {
          const response = await api.post('/get-files', {
            fileIds: ticket.prilozhenie_k_zaprosu,
          });

          if (response.data.success) {
            setZaprosFiles(response.data.files);
          }
        } catch (error) {
            console.error('Ошибка загрузки превью файлов:', error);
        }
      }

      if ((ticket.prilozhenie_k_zaprosu?.length ?? 0) > 0) {
        fetchFiles();
      }

    }, [ticket.prilozhenie_k_zaprosu])

    useEffect(() => {
        const fetchFiles = async () => {
        try {
          const response = await api.post('/get-files', {
          fileIds: ticket?.marshrutnaya_kvitanciya,
          });

          if (response.data.success) {
              setFiles(response.data.files);
          } else {
              console.error('Ошибка на сервере:', response.data.error);
          }

        } catch (error) {
            console.error('Ошибка загрузки файлов:', error);
        }
        };

        fetchFiles();
    }, [ticket]);


    useEffect(() => {
        if (!ticket?.__id) return;
        dispatch(fetchMessages(ticket.__id));
        setIsLoading(false);
    }, []);
  
    const selectedChat: ChatsType = {
      id: ticket?.__id ?? '',
      taskId: ticket?.__id || '',
      name: ticket?.nomer_zakaza || '',
      status: 'UPLOAD',
      recent: true,
      excerpt: '',
      chatHistory: [],
      messages: currentChats?.messages?.[0]?.target.id === ticket.__id ? currentChats : [],
    };

    const status = getStatus(ticket);

    let colorStatus = 'black';
    let backgroundStatus = 'grey';

    switch(status) {
        case AllStatus.NEW:
            backgroundStatus = 'warning.light';
            break;
        case AllStatus.PENDING:
            backgroundStatus = 'success.light';
            break;
        case AllStatus.BOOKED:
            backgroundStatus = 'pink';
            break;
        case AllStatus.FORMED:
            backgroundStatus = '#a52a2a1f';
            break;
        case AllStatus.FORMED:
            backgroundStatus = 'error.light';
            break;
        default:
            colorStatus = 'primary'
        }


    type GetTicketFieldType = {
        ticket: ELMATicket;
    }

//     const GetTicketFields = (props: GetTicketFieldType) => {
//         const {ticket} = props;
//         const status = getStatus(ticket);

//         switch(status) {
//             case AllStatus.NEW:
//                 return(
//                     null
//                 )
//             case AllStatus.PENDING:
//             return(
//                 <React.Fragment>
//                     <Typography mt={0} fontWeight={600}>Маршрут и стоимость: <Typography mt={0} variant="caption">{(ticket?.otvet_klientu3 ?? ticket?.otvet_klientu ?? ticket?.otvet_klientu1)
//                       ?.split('✈️')
//                       .filter(Boolean)
//                       .map((part, idx, arr) => {
//                         let content = '✈️' + part.trim();
                        
//                         // Сплит по \n и вставка <br />
//                         const lines = content.split('\n');
          
//                         return (
//                           <React.Fragment key={idx}>
//                             {idx > 0 ? <><br /><br /></> : <><br/></>}
//                             {lines.map((line, i) => (
//                               <React.Fragment key={i}>
//                                 {line}
//                                 {i < lines.length - 1 && <br />}
//                               </React.Fragment>
//                             ))}
//                           </React.Fragment>
//                         );
//                       })}
// </Typography></Typography>
//                       <br/>
//                     <Typography mt={0} fontWeight={600}>Тайм-лимит:<br/><Typography mt={0} variant="caption">До {formatToRussianDate(ticket.taim_limit_dlya_klienta ?? '')}</Typography></Typography>

//                 </React.Fragment>
//             )
//             case AllStatus.BOOKED:
//             return(
//                 <React.Fragment>
//                     {(ticket?.fio2?.length ?? 0) > 0 && <>
//                     <Typography fontWeight={600}>Пассажир(ы):</Typography>
//                         {ticket?.fio2?.map((currentId) => 
//                         <Typography sx={{
//     wordBreak: 'break-word', // переносит по символам при необходимости
//     whiteSpace: 'pre-wrap',  // сохраняет переносы строк, если они есть
//     overflowWrap: 'break-word', // дополнительная совместимость
//   }} key={currentId}>
//                             {passports[currentId]?.[0]} - {passports[currentId]?.[1]}
//                         </Typography>
//                    )}</>}
//                     <br/>
//                     <Typography mt={0} fontWeight={600}>Маршрут и стоимость:<Typography whiteSpace="pre-line" mt={0} variant="caption">{(ticket?.otvet_klientu3 ?? ticket?.otvet_klientu ?? ticket?.otvet_klientu1)
//                       ?.split('✈️')
//                       .filter(Boolean)
//                       .map((part, idx, arr) => {
//                         let content = '✈️' + part.trim();
                        
//                         // Сплит по \n и вставка <br />
//                         const lines = content.split('\n');
          
//                         return (
//                           <React.Fragment key={idx}>
//                             {idx > 0 ? <><br /><br /></> : <><br/></>}
//                             {lines.map((line, i) => (
//                               <React.Fragment key={i}>
//                                 {line}
//                                 {i < lines.length - 1 && <br />}
//                               </React.Fragment>
//                             ))}
//                           </React.Fragment>
//                         );
//                       })}
//       </Typography></Typography>
//                     <br/>
//                     {/* <br/> */}
//                     {/* {ticket.otvet_klientu3 && <Typography mt={0} variant="caption"> {ticket.otvet_klientu3}</Typography>} */}
//                 </React.Fragment>
//             )
//             case AllStatus.FORMED:
//             return(
//                 <React.Fragment>
//                     {(ticket?.fio2?.length ?? 0) > 0 && <>
//                     <Typography fontWeight={600}>Пассажир(ы):</Typography>
//                         {ticket?.fio2?.map((currentId) => 
//                         <Typography sx={{
//     wordBreak: 'break-word', // переносит по символам при необходимости
//     whiteSpace: 'pre-wrap',  // сохраняет переносы строк, если они есть
//     overflowWrap: 'break-word', // дополнительная совместимость
//   }} key={currentId}>
//                             {passports[currentId]?.[0]} - {passports[currentId]?.[1]}
//                         </Typography>
//                    )}</>}
//                     <br/>
//                     {/* <Typography mt={0} fontWeight={600}>Маршрут и стоимость:<Typography whiteSpace="pre-line" mt={0} variant="caption"> {
//                     (ticket.otvet_klientu3 ?? ticket.otvet_klientu ?? ticket.otvet_klientu1)?.split('✈️')
//   .map((part, idx) => {
//     if (!part.trim()) return null; // пропустить пустые части

//     const contentWithPlane = (idx !== 0 ? '✈️' : '') + part.trim();

//     // добавляем перенос строки после последнего времени в каждом сегменте
//     const formatted = contentWithPlane.replace(
//   /(\d{2}:\d{2})(?!.*\d{2}:\d{2})(?![^]*✈️)(.*)/s,
//   '$1$2'
// );

//     return (
//       <React.Fragment key={idx}>
//         {idx !== 0 && <><br /><br /></>}
//         {formatted}
//       </React.Fragment>
//     );
//   })}

// </Typography></Typography>
//                     <br/> */}
//                     <Typography mt={0} fontWeight={600}>Итоговая стоимость:<Typography mt={0} variant="caption"> {ticket.itogovaya_stoimost.cents}</Typography></Typography>
//                     <br/>
//                    {ticket && getStatus(ticket) === AllStatus.FORMED && <><Typography fontWeight={600}>Маршрутная квитанция:</Typography>
//           <Stack spacing={2.5} direction="column" mt={1}>
//        {files.map((file) => (
//          <Stack key={file.fileId} direction="row" gap={2} alignItems="center">
//            <Avatar
//              variant="rounded"
//              sx={{
//                width: 48,
//                height: 48,
//                bgcolor: (theme) => theme.palette.grey[100],
//              }}
//            >
//              <Avatar
//                src="data:image/svg+xml,%3csvg%20width='24'%20height='24'%20viewBox='0%200%2024%2024'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cg%20clip-path='url(%23clip0_631_1669)'%3e%3cpath%20d='M23.993%200H0.00703125C0.003148%200%200%200.003148%200%200.00703125V23.993C0%2023.9969%200.003148%2024%200.00703125%2024H23.993C23.9969%2024%2024%2023.9969%2024%2023.993V0.00703125C24%200.003148%2023.9969%200%2023.993%200Z'%20fill='%23ED2224'/%3e%3cpath%20d='M13.875%205.625L19.2188%2018.375V5.625H13.875ZM4.78125%205.625V18.375L10.125%205.625H4.78125ZM9.70312%2015.7969H12.1406L13.2188%2018.375H15.375L11.9531%2010.2656L9.70312%2015.7969Z'%20fill='white'/%3e%3c/g%3e%3cdefs%3e%3cclipPath%20id='clip0_631_1669'%3e%3crect%20width='24'%20height='24'%20rx='3'%20fill='white'/%3e%3c/clipPath%3e%3c/defs%3e%3c/svg%3e"
//                alt="file icon"
//                variant="rounded"
//                sx={{ width: 24, height: 24 }}
//              />
//            </Avatar>

//            <Box flexGrow={1} overflow="hidden">
//              <Typography noWrap>{decodeURIComponent(file.filename)}</Typography>
//            </Box>

//            <Box display="flex" gap={1}>
//              <IconButton aria-label="view" onClick={() => handleViewFile(file)}>
//                <IconEye stroke={1.5} size="20" />
//              </IconButton>
//              <IconButton aria-label="download" onClick={() => handleDownloadFile(file)}>
//                <IconDownload stroke={1.5} size="20" />
//              </IconButton>
//            </Box>
//          </Stack>
//        ))}</Stack></>}
//                 </React.Fragment>
//             )
//             case AllStatus.CLOSED:
//             return(
//                 <React.Fragment>
//                     {(ticket?.fio2?.length ?? 0) > 0 && <>
//                     <Typography fontWeight={600}>Пассажир(ы):</Typography>
//                         {ticket?.fio2?.map((currentId) => 
//                         <Typography sx={{
//     wordBreak: 'break-word', // переносит по символам при необходимости
//     whiteSpace: 'pre-wrap',  // сохраняет переносы строк, если они есть
//     overflowWrap: 'break-word', // дополнительная совместимость
//   }} key={currentId}>
//                             {passports[currentId]?.[0]} - {passports[currentId]?.[1]}
//                         </Typography>
//                    )}</>}
//                     <br/>
//                     <Typography mt={0} fontWeight={600}>Маршрут и стоимость:<Typography whiteSpace="pre-line" mt={0} variant="caption"> {(ticket?.otvet_klientu3 ?? ticket?.otvet_klientu ?? ticket?.otvet_klientu1)
//                     ?.split('✈️')
//                     .filter(Boolean)
//                     .map((part, idx, arr) => {
//                       let content = '✈️' + part.trim();
                      
//                       // Сплит по \n и вставка <br />
//                       const lines = content.split('\n');
        
//                       return (
//                         <React.Fragment key={idx}>
//                           {idx > 0 ? <><br /><br /></> : <><br/></>}
//                           {lines.map((line, i) => (
//                             <React.Fragment key={i}>
//                               {line}
//                               {i < lines.length - 1 && <br />}
//                             </React.Fragment>
//                           ))}
//                         </React.Fragment>
//                       );
//                     })}

// </Typography></Typography>
//                     <br/>
//                     <Typography mt={0} fontWeight={600}>Итоговая стоимость:<Typography mt={0} variant="caption"> {ticket.itogovaya_stoimost.cents}</Typography></Typography>
//                     <br/>
//                    {ticket && getStatus(ticket) === AllStatus.FORMED && <><Typography fontWeight={600}>Маршрутная квитанция:</Typography>
//           <Stack spacing={2.5} direction="column" mt={1}>
//        {files.map((file) => (
//          <Stack key={file.fileId} direction="row" gap={2} alignItems="center">
//            <Avatar
//              variant="rounded"
//              sx={{
//                width: 48,
//                height: 48,
//                bgcolor: (theme) => theme.palette.grey[100],
//              }}
//            >
//              <Avatar
//                src="data:image/svg+xml,%3csvg%20width='24'%20height='24'%20viewBox='0%200%2024%2024'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cg%20clip-path='url(%23clip0_631_1669)'%3e%3cpath%20d='M23.993%200H0.00703125C0.003148%200%200%200.003148%200%200.00703125V23.993C0%2023.9969%200.003148%2024%200.00703125%2024H23.993C23.9969%2024%2024%2023.9969%2024%2023.993V0.00703125C24%200.003148%2023.9969%200%2023.993%200Z'%20fill='%23ED2224'/%3e%3cpath%20d='M13.875%205.625L19.2188%2018.375V5.625H13.875ZM4.78125%205.625V18.375L10.125%205.625H4.78125ZM9.70312%2015.7969H12.1406L13.2188%2018.375H15.375L11.9531%2010.2656L9.70312%2015.7969Z'%20fill='white'/%3e%3c/g%3e%3cdefs%3e%3cclipPath%20id='clip0_631_1669'%3e%3crect%20width='24'%20height='24'%20rx='3'%20fill='white'/%3e%3c/clipPath%3e%3c/defs%3e%3c/svg%3e"
//                alt="file icon"
//                variant="rounded"
//                sx={{ width: 24, height: 24 }}
//              />
//            </Avatar>

//            <Box flexGrow={1} overflow="hidden">
//              <Typography noWrap>{decodeURIComponent(file.filename)}</Typography>
//            </Box>

//            <Box display="flex" gap={1}>
//              <IconButton aria-label="view" onClick={() => handleViewFile(file)}>
//                <IconEye stroke={1.5} size="20" />
//              </IconButton>
//              <IconButton aria-label="download" onClick={() => handleDownloadFile(file)}>
//                <IconDownload stroke={1.5} size="20" />
//              </IconButton>
//            </Box>
//            </Stack>
//        ))}</Stack></>}
//                 </React.Fragment>
//             )
//         }
//     } 


    const bookingDataList = [];

    // Бронь №1
    bookingDataList.push({
      fio: ticket.fio2,
      passport: ticket.nomer_a_pasporta_ov_dlya_proverki,
      marshrut: ticket.otvet_klientu,
      timeLimit: ticket.taim_limit_dlya_klienta,
      preAnswer: ticket.otvet_klientu3,
      code: ticket.kod_bronirovaniya_v_sisteme,
    });

    // Брони №2–6
    for (let i = 2; i <= 6; i++) {
      const currentTicket: any = ticket;
      const data = {
        fio: currentTicket[`fio_passazhira_ov_bron_${i}`],
        passport: currentTicket[`nomer_a_pasporta_ov_dlya_proverki_bron_${i}`],
        marshrut: currentTicket[`otvet_klientu_o_bronirovanii_${i}`],
        timeLimit: currentTicket[`taim_limit_dlya_klienta_bron_${i}`],
        preAnswer: currentTicket[`otvet_klientu3_bron_${i}`],
        code: currentTicket[`kod_bronirovaniya_v_sisteme_bron_${i}`] || currentTicket[`dopolnitelnyi_kod_bronirovaniya`],
      };

      const isEmpty = Object.values(data).every((val) => !val);
      if (!isEmpty) {
        bookingDataList.push(data);
      }
    }

    const handleTabChange = (_: React.SyntheticEvent, newIndex: number) => {
      setTabIndex(newIndex);
    };

    const aviabilety = bookingDataList.map((data, index) =>
      Object.values(data).some(val => Array.isArray(val) ? val.length > 0 : val) && (
        <Accordion key={index} defaultExpanded={index === 0}>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography fontWeight="bold">Бронь №{index + 1}</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <BookingInfoBlock
              bookingNumber={index + 1}
              ticket={ticket}
              passports={passports}
            />
          </AccordionDetails>
        </Accordion>
      )
    );

    return (
    <InvoiceProvider>
      <PageContainer title={`Заказ №${ticket.nomer_zakaza}`} description="this is Invoice Detail">
        <BlankCard>
          <CardContent>
            <Stack
              direction={{ xs: 'column', sm: 'row' }}
              alignItems="center"
              justifyContent="space-between"
              mb={2}
            >
              <Box textAlign={{ xs: 'center', sm: 'left' }}>
                <Typography variant="h5"># {ticket.nomer_zakaza}</Typography>
                <Box mt={1}>
                  <Chip
                    size="small"
                    color="secondary"
                    variant="outlined"
                    label={formatToRussianDate(ticket.__createdAt, 'd MMMM yyyy / hh:mm')}
                  />
                </Box>
              </Box>

              <Box>
                <Logo />
              </Box>

              <Box textAlign="right">
                <Chip
                  size="small"
                  sx={{ color: colorStatus, backgroundColor: backgroundStatus }}
                  label={status}
                />
              </Box>
            </Stack>

            <Divider />

            <Grid container spacing={3} mt={2} mb={4}>
              <Grid item xs={12} sm={8}>
                <Grid container spacing={2}>
                  <Grid item xs={12} sm={(ticket.zapros || (ticket.prilozhenie_k_zaprosu?.length ?? 0) > 0) ? 5 : 12}>
                    <Paper variant="outlined">
                      <Box p={3} display="flex" flexDirection="column" gap="4px">
                        <Typography variant="body1" mb={1}>
                          {ticket.zapros}
                        </Typography>

                        {zaprosFiles.map((file) => {
                          const filename = decodeURIComponent(file.filename);
                          const extension = filename.split('.').pop()?.toLowerCase();
                          const isImage = ['png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp'].includes(extension || '');

                          return (
                            <Stack key={file.fileId} direction="row" gap={2} alignItems="center">
                              {isImage ? (
                                <Box
                                  component="img"
                                  src={file.url}
                                  alt={filename}
                                  sx={{
                                    width: 100,
                                    height: 100,
                                    objectFit: 'cover',
                                    borderRadius: 1,
                                    border: '1px solid #ccc',
                                  }}
                                  onClick={() => {
                                    dispatch(showFilePreview({
                                        url: file.url ?? '',
                                        name: file.filename ?? '',
                                        type: '',
                                    } ));
                                  }}
                                />
                              ) : (
                                <Avatar
                                  variant="rounded"
                                  sx={{ width: 48, height: 48, bgcolor: theme.palette.grey[100] }}
                                >
                                  <IconFile color="#4570EA" />
                                </Avatar>
                              )}

                              <Box flexGrow={1} overflow="hidden">
                                <Typography noWrap>{filename}</Typography>
                              </Box>

                              <Box display="flex" gap={1}>
                                <IconButton aria-label="download" onClick={() => handleDownloadFile(file)}>
                                  <IconDownload stroke={1.5} size="20" />
                                </IconButton>
                              </Box>
                            </Stack>
                          );
                        })}
                      </Box>
                    </Paper>
                  </Grid>

                  {ticket && (
                    <Grid item xs={12} sm={7} mt={isMobile ? 1 : 0}>
                       <Paper variant="outlined" sx={{ p: 2 }}>
                      <Tabs value={tabIndex} onChange={handleTabChange} variant="scrollable" scrollButtons="auto">
                        <Tab label="Авиабилеты" />
                        <Tab label="Отели" />
                        <Tab label="Трансфер" />
                        <Tab label="ВИП сервис" />
                        <Tab label="Карта мест" />
                      </Tabs>

                      {/* Контент вкладок */}
                      <Box mt={2}>
                        {tabIndex === 0 && (
                          <Box>
                            {aviabilety.some((el) => el) ? aviabilety : <Paper sx={{ p: 3, my: 2, borderRadius: 2, backgroundColor: '#f9f9f9' }}>
                              <Typography>Нет данных по авиабилетам</Typography>
                            </Paper>}
                          </Box>
                        )}

                        {tabIndex === 1 && (
                          <HotelsBlock ticket={ticket} />
                        )}

                        {tabIndex === 2 && (
                          <TransferBlock ticket={ticket} />
                        )}

                        {tabIndex === 3 && (
                          <VipServiceBlock ticket={ticket} />
                        )}

                        {tabIndex === 4 && (
                          <MapBlock ticket={ticket} />
                        )}
                      </Box>
                    </Paper>
                    </Grid>
                  )}
                </Grid>
              </Grid>

              <Grid item xs={12} sm={4}>
                {ticket?.__id && selectedChat.messages && <MiniChat selectedChat={selectedChat} />}
              </Grid>
            </Grid>

            <Box display="flex" alignItems="center" gap={1} mt={3} justifyContent="flex-end">
              <Button variant="contained" color="secondary" component={Link} to={`/apps/chats?item=${ticket.nomer_zakaza}`}>
                Перейти в чат
              </Button>
              <Button variant="contained" color="primary" onClick={onClose}>
                Вернуться к заказам
              </Button>
            </Box>
          </CardContent>

          <DialogViewer
            openViewer={openViewer}
            handleCloseViewer={handleCloseViewer}
            pdfBlobUrl={pdfBlobUrl}
            pageNumber={pageNumber}
            setPageNumber={setPageNumber}
            numPages={numPages}
            setNumPages={setNumPages}
          />
        </BlankCard>
      </PageContainer>
    </InvoiceProvider>
  );
};
export default ModalDetails;
