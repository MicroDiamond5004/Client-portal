import { Typography, Paper } from "@mui/material";
import React from "react";
import { useAppDispatch } from "src/store/hooks";
import { showFilePreview } from "src/store/slices/filePreviewSlice";

type FileListBlockProps = {
  title?: string;
  files: any[];
  originalFiles: any[];
};

export const FileListBlock: React.FC<FileListBlockProps> = ({ title = "Файлы", files, originalFiles }) => {
  const dispatch = useAppDispatch();

  if (!originalFiles || originalFiles.length === 0) return null;

  return (
    <Paper
      elevation={3}
      sx={{
        p: 3,
        my: 2,
        borderRadius: 2,
        backgroundColor: "#f9f9f9",
      }}
    >
      <Typography variant="h5" sx={{ mb: 2 }}>
        {title}
      </Typography>

      {originalFiles.map((file: any) => (
        <Typography
          key={file.__id}
          onClick={() => {
            const found = files.find((el) => el.fileId === file.__id);
            if (found) {
              dispatch(
                showFilePreview({
                  url: found.url ?? "",
                  name: file.originalName ?? "",
                  type: "", // можно указать found.mimeType, если нужно
                })
              );
            }
          }}
          sx={{
            cursor: "pointer",
            color: "#1976d2",
            textDecoration: "underline",
            mb: 1,
            wordBreak: "break-word",
          }}
        >
          {file.originalName}
        </Typography>
      ))}
    </Paper>
  );
};
