import { Box } from "@mui/system";
import { ChatContext, ChatProvider } from "src/context/ChatContext";
import ChatContent from "../../chats/ChatContent";
import { Avatar, Divider, ListItemAvatar, Typography } from "@mui/material";
import ChatMsgSent from "../../chats/ChatMsgSent";
import { IconMenu2 } from "@tabler/icons-react";
import { formatDistanceToNowStrict } from "date-fns";
import { ChatMessage, ChatsType } from "src/types/apps/chat";
import SimpleBar from "simplebar-react";
import { useContext, useEffect, useRef, useState } from "react";
import { stripHtmlAndDecode } from "../../chats/ChatListing";
import { flatMap } from "lodash";

function MiniChat({selectedChat}: any) {
    const mainBoxRef = useRef<HTMLElement>(null);
    const inBoxRef = useRef<HTMLElement>(null);

      const { selectedChat: currentChat, setSelectedChat } = useContext(ChatContext);
      const [replyToMsg, setReplyToMsg] = useState<ChatMessage | null>(null);

    // const {selectedChat: currentChat, setSelectedChat} = useContext(ChatContext);


    return (
    <Box flexGrow={1} border={'1px solid #e5eaef'}>
    <SimpleBar>
      <Box sx={{display: 'flex', flexWrap: 'wrap'}}>
        {selectedChat ? (
          <Box width={'100%'}> 
            {/* ------------------------------------------- */}
            {/* Chat Content */}
            {/* ------------------------------------------- */}

            <Box sx={{display: 'flex', width: 'auto', overflow: 'hidden'}} ref={mainBoxRef}>
              {/* ------------------------------------------- */}
              {/* Chat msges */}
              {/* ------------------------------------------- */}

              <Box>
                <Box
                  sx={{
                    height: "auto",
                    overflow: "auto",
                    maxHeight: "800px",
                    width: mainBoxRef && inBoxRef && ((mainBoxRef.current?.clientWidth || 0) - (inBoxRef.current?.clientWidth || 0)) > 300 ?
                     `${((mainBoxRef.current?.clientWidth || 0) - (inBoxRef.current?.clientWidth || 0))}px` : '300px',
                  }}
                >
                  <ChatContent onReply={(message: ChatMessage) => setReplyToMsg(message)} replyToMsg={replyToMsg} cancelReply={() => setReplyToMsg(null)} needSidebar={false} />
                </Box>
              </Box>

              {/* ------------------------------------------- */}
              {/* Chat right sidebar Content */}
              {/* ------------------------------------------- */}
            </Box>
          </Box>
        ) : (<></>)}
      </Box>
    </SimpleBar>
      <Divider />
      <ChatMsgSent
        currentChat={selectedChat}
        updateChat={(chat) => setSelectedChat(chat)}
        replyToMsg={replyToMsg} 
        cancelReply={() => setReplyToMsg(null)}
      />
    </Box>
    )
}

export default MiniChat;