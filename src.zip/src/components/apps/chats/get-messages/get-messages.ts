import { ELMATicket } from "src/mocks/tickets/ticket.type";
import { ChatsType } from "src/types/apps/chat";

function getMessagesFromTicket(ticket: ELMATicket | null): ChatsType | null {
    if (ticket) {
        
    }
    return null;
}