import React, { useContext, useEffect, useState } from "react";
import Box from "@mui/material/Box";
import IconButton from "@mui/material/IconButton";
import InputBase from "@mui/material/InputBase";
import Typography from "@mui/material/Typography";

import { IconPaperclip, IconPhoto, IconSend } from "@tabler/icons-react";
import { ChatContext } from "src/context/ChatContext";
import { sendPushFromClient } from "src/utils/pushManager";
import { ChatMessage, ChatsType } from "src/types/apps/chat";
import { useAppDispatch, useAppSelector } from "src/store/hooks";
import {
  fetchMessages,
  sendComment,
  sendMessage as sendElmaMessage,
} from "src/store/middleware/thunks";
import { selectClientName } from "src/store/selectors/authSelector";
import '../chats/chat.css';
import { stripHtml } from "src/utils/stripHTML";
import { selectTickets } from "src/store/selectors/ticketsSelectors";

type ChatMsgSentProps = {
  currentChat: ChatsType | null;
  updateChat: (chat: ChatsType | null) => void;
  replyToMsg?: any | null;
  cancelReply?: () => void;
};

const ChatMsgSent = ({
  currentChat,
  updateChat,
  replyToMsg,
  cancelReply,
}: ChatMsgSentProps) => {
  const dispatch = useAppDispatch();
  const clientName = useAppSelector(selectClientName);
  const tickets = useAppSelector(selectTickets);
  const { selectedChat } = useContext(ChatContext);

  const [msg, setMsg] = useState("");
  const [files, setFiles] = useState<File[]>([]);

  // console.log(tickets);

  const handleChatMsgChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setMsg(e.target.value);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles([...files, ...Array.from(e.target.files)]);
    }
  };

  const handleRemoveFile = (index: number) => {
    const newFiles = [...files];
    newFiles.splice(index, 1);
    setFiles(newFiles);
  };

  const handleSendMessage = async (commentMessage: ChatMessage | null = null) => {
    if (!msg.trim() && files.length === 0) return;

    const chatId = selectedChat?.taskId || currentChat?.taskId || "";
    const orderNumber = selectedChat?.name || currentChat?.name || "";

    if (commentMessage) {
      // console.log(commentMessage); 
      // Отправка комментария к сообщению
      dispatch(fetchMessages(chatId));
      cancelReply?.();
      dispatch(sendComment({ id: commentMessage.messageId ?? commentMessage.id, text: msg, files }));
      dispatch(fetchMessages(selectedChat?.taskId || currentChat?.taskId || ''));
      setFiles([]);
      // sendPushFromClient(msg, `Заказ - ${currentChat?.name}`);
      setMsg("");
      return;
    }

    // console.log(files);
    dispatch(fetchMessages(selectedChat?.taskId || currentChat?.taskId || ''));
    cancelReply?.();
    const url = tickets.find((el: any) => el.nomer_zakaza === orderNumber)?.ssylka_na_kartochku ?? '';
    // console.log(url);
    dispatch(sendElmaMessage({ id: chatId, text: msg, orderNumber, files, url }));
    setFiles([]);
    // sendPushFromClient(msg, `Заказ - ${orderNumber}`);
    setMsg("");
    
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage(replyToMsg);
    }
  };

  useEffect(() => {
    return () => {
      files.forEach((file) => URL.revokeObjectURL(URL.createObjectURL(file)));
    };
  }, [files]);

  const replyedText = replyToMsg ? stripHtml(replyToMsg?.msg?.trim()
    ? replyToMsg.msg
    : replyToMsg.body ? replyToMsg.body : replyToMsg.files?.length
    ? `📎 ${replyToMsg.files[0].__name || replyToMsg.files[0].name}`
    : "[Пустое сообщение]") : '';

  return (
    <Box p={2}>
      {/* Блок ответа на сообщение */}
      {replyToMsg && (
        <Box
          display="flex"
          alignItems="center"
          justifyContent="space-between"
          bgcolor="grey.100"
          px={2}
          py={1}
          mb={1}
          borderLeft="4px solid #1976d2"
          borderRadius={1}
        >
          <Box flexGrow={1} pr={2}>
            <Typography fontSize={12} color="text.secondary">
              Ответ на сообщение
            </Typography>
            <Typography fontSize={14}>
              {replyedText.length > 100 ? `${replyedText.slice(0, 100)}...` : replyedText}
            </Typography>
          </Box>
          <IconButton onClick={cancelReply} size="small">
            ✕
          </IconButton>
        </Box>
      )}

      {/* Selected Files Review */}
      {files.length > 0 && (
        <Box display="flex" flexWrap="wrap" gap={1} mb={1}>
          {files.map((file, index) => (
            <Box key={index} position="relative">
              {file.type.startsWith("image/") ? (
                <img
                  src={URL.createObjectURL(file)}
                  alt={file.name}
                  width={80}
                  height={80}
                  style={{ objectFit: "cover", borderRadius: 4 }}
                />
              ) : (
                <Box
                  width={80}
                  height={80}
                  display="flex"
                  alignItems="center"
                  justifyContent="center"
                  bgcolor="grey.200"
                  borderRadius={4}
                >
                  <Typography variant="caption" align="center">
                    {file.name}
                  </Typography>
                </Box>
              )}
              <IconButton
                size="small"
                onClick={() => handleRemoveFile(index)}
                style={{
                  position: "absolute",
                  top: -10,
                  right: -10,
                  backgroundColor: "white",
                }}
              >
                ✕
              </IconButton>
            </Box>
          ))}
        </Box>
      )}

      {/* Поле ввода и кнопки */}
      <Box display="flex" gap="10px" alignItems="center">
        <InputBase
          id="msg-sent"
          fullWidth
          value={msg}
          placeholder="Ваше сообщение"
          size="small"
          type="text"
          inputProps={{ "aria-label": "Ваше сообщение" }}
          onChange={handleChatMsgChange}
          onKeyDown={handleKeyPress}
        />

        <IconButton
          aria-label="send"
          onClick={() => handleSendMessage(replyToMsg)}
          disabled={!msg.trim() && files.length === 0}
          color="primary"
        >
          <IconSend stroke={1.5} size="20" />
        </IconButton>

        <label htmlFor="file-upload">
          <IconButton component="span" aria-label="attach">
            <IconPaperclip stroke={1.5} size="20" />
          </IconButton>
        </label>
        <input
          accept="image/*,application/pdf"
          id="file-upload"
          multiple
          type="file"
          style={{ display: "none" }}
          onChange={handleFileChange}
        />
      </Box>
    </Box>
  );
};

export default ChatMsgSent;
