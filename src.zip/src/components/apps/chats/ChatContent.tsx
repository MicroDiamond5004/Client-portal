import React, { useContext, useEffect, useRef, useState } from 'react';
import DOMPurify from 'dompurify';
import {
  Typography,
  Divider,
  Avatar,
  ListItem,
  ListItemText,
  ListItemAvatar,
  IconButton,
  Box,
  Stack,
  Badge,
  useMediaQuery,
  Theme,
  Button,
  ImageListItem,
  ImageList
} from '@mui/material';
import { IconArrowBarToDown, IconDotsVertical, IconDownload, IconEye, IconMenu2, IconMessageReply, IconPhone, IconShare, IconVideo } from '@tabler/icons-react';
import { formatDistanceToNowStrict } from 'date-fns';
import ChatInsideSidebar from './ChatInsideSidebar';
import { ChatContext } from "src/context/ChatContext";
import { ChatMessage, ChatsType } from 'src/types/apps/chat';
import formatToRussianDate, { formatToRussianDateSmart } from 'src/help-functions/format-to-date';
import SimpleBar from 'simplebar-react';
import { isEqual, uniqueId } from 'lodash';
import { ReplyAll, ReplyAllRounded, ReplyAllSharp } from '@mui/icons-material';
import api from 'src/store/api';
import { messages } from 'src/layouts/full/vertical/header/data';
import { users } from 'src/api/userprofile/UsersData';
import { useAppDispatch, useAppSelector } from 'src/store/hooks';
import { selectClientId } from 'src/store/selectors/authSelector';
import { getColorByLetter } from 'src/utils/getColorByLetter';
import { showFilePreview } from 'src/store/slices/filePreviewSlice';


const ChatContent = ({ onReply, replyToMsg, cancelReply, needSidebar: open}: { onReply: (message: any) => void, replyToMsg: any | null, cancelReply: () => void, needSidebar: boolean}) => {
  const lgUp = useMediaQuery((theme: Theme) => theme.breakpoints.up("lg"));

  const {selectedChat} = useContext(ChatContext);

  const dispatch = useAppDispatch();

  const mainBoxRef = useRef<HTMLElement>(null);
  const inBoxRef = useRef<HTMLElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const [currentChat, setCurrentChat] = useState<string>()

  const [files, setFiles] = useState<any[]>([]);
  const [managers, setManagers] = useState<Record<string, string>>({});

  const clientId = useAppSelector(selectClientId);
  const [selectedFile, setSelectedFile] = useState<{
    url: string;
    name: string;
    type: string;
  } | null>(null);

  useEffect(() => {
    if (currentChat !== selectedChat?.taskId) {
      setCurrentChat(selectedChat?.taskId);
    }
  }, [selectedChat])

  useEffect(() => {
    cancelReply();
    setTimeout(() => {
      if (messagesEndRef.current) {
        messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
      }
    }, currentChat ? 500 : 3000);
  }, [currentChat]);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        if (!selectedChat?.messages?.length) return;
  
        const userIds = new Set<string>();
  
        for (const message of selectedChat.messages) {
          if (message.author) userIds.add(message.author);
          if (message.comments?.length) {
            for (const comment of message.comments) {
              if (comment.author) userIds.add(comment.author);
            }
          }
        }
  
        const currentUsers = Array.from(userIds);
  
        const knownUserIds = Object.keys(managers);
        const isSame =
          currentUsers.length === knownUserIds.length &&
          currentUsers.every((id) => managers.hasOwnProperty(id));
  
        if (!isSame) {
          const response = await api.post('/getManagers', { users: currentUsers });
  
          const data = response.data; // массив имён
  
          const updatedManagers: Record<string, string> = {};
          for (let i = 0; i < currentUsers.length; i++) {
            const userId = currentUsers[i];
            updatedManagers[userId] = data[i] || '[unknown]';
          }
  
          setManagers((prev) => ({ ...prev, ...updatedManagers }));
        }
      } catch (error) {
        console.error('Failed to fetch managers:', error);
      }
    };
  
    fetchUsers();
  }, [selectedChat]);
  
  
  useEffect(() => {
      const fetchFiles = async () => {
        try {
          const allFiles: any[] = [];

          const allMainFiles = selectedChat?.messages?.map((message) => message.files).filter((files) => (files?.length ?? 0) > 0);
          const allCommentsFiles = selectedChat?.messages?.map((message) => message?.comments?.map((comment) => comment.files).filter((files) => (files?.length ?? 0) > 0)).filter((files) => (files?.length ?? 0) > 0);

          allMainFiles?.map((files) => files?.forEach((file) => allFiles?.push(file)))
          allCommentsFiles?.map((files) => files?.forEach((file) => file.forEach((currentFile: any) => allFiles?.push(currentFile))));

          if (allFiles.length > 0) {
            const response = await api.post('/get-files', {
              fileIds: allFiles.map((file) => file.__id),
            });
            
            
            if (response.data.success) {
              const fetchedFiles: any[] = response.data.files;
              if (fetchedFiles.length !== files.length) {
                setFiles(fetchedFiles);
              }
            } else {
              console.error('Ошибка на сервере:', response.data.error);
            }
          }
  
        } catch (error) {
          console.error('Ошибка загрузки файлов:', error);
        }
      };
  
      fetchFiles()
  }, [selectedChat])

  const handleMessageClick = (message: any) => {
    if ((replyToMsg?.id || replyToMsg?.__id) === (message.id || message.__id)) {
      cancelReply();
    } else {
      onReply(message);
    }
  };

  const handleViewFile = async (url: any) => {
      window.open(url, '_blank');
      return;
  };
  

  // // // console.log(selectedChat?.id, selectedChat?.messages[selectedChat?.messages.length - 1], 'ffffffffffffffffffffffffffffffffffff');

  // // console.log(files);

  // Главная сортировка по датам
  const AllMainMessages: any = {};
  const AllMessages: any[] = [];

  selectedChat?.messages?.forEach((message) => {
    AllMessages.push({...message, comments: []});
    AllMainMessages[message.id] = {...message, comments: []};
    message.comments?.forEach((comment, index) => {
      AllMessages.push({...comment, prevComment: index > 0 ? message.comments?.[index - 1] : null, messageId: message.id, senderId: comment.author === clientId ? '0' : selectedChat.name});
    })
  })

  const sortedMessages = AllMessages.sort(
    (a: any, b: any) => new Date(a.__createdAt ?? a.createdAt).getTime() - new Date(b.__createdAt ?? b.createdAt).getTime()
  );

  const scrollToMessage = (messageId: any) => {
    if (!messageId) return;

    const target = document.getElementById(`${messageId}`);
    if (target) {
      target.scrollIntoView({ behavior: "smooth", block: "center" });
      target.parentElement?.parentElement?.parentElement?.parentElement?.classList.add("highlight-message");

      setTimeout(() => {
        target.parentElement?.parentElement?.parentElement?.parentElement?.classList.remove("highlight-message");
      }, 1500);
    }
  };

  const getMessages = (chat: any, index: number) => { 

    // Отчищение сообщений
    // console.log(chat.msg ?? chat.body);

    const cleaned = (chat.msg ?? chat.body)?.trim() ?? '';

    // Делаем безопасный текст
    let safeHtml = cleaned
    ? DOMPurify.sanitize(cleaned?.replace(/\r?\n/g, '<br/>'))
      : null;

    // Тоже самое делаем для комментариев
    // const commentsHTML = chat?.comments.map((comment: any) => DOMPurify.sanitize(comment.body));

    if (selectedChat && (chat.senderId === selectedChat.name && !!chat.messageId)) {
      const replyedMessage = chat.prevComment ? {
        attachment: [],
        author: chat.prevComment.author,
        comments: [],
        createdAt: chat.prevComment.__createdAt,
        id: chat.prevComment.__id,
        msg: chat.prevComment?.body,
        senderId: chat.prevComment?.author === clientId ? '0' : selectedChat.name,
        type: "text",
        messageId: chat.messageId,
      } : AllMainMessages[chat.messageId];

      safeHtml = DOMPurify.sanitize(cleaned?.replace(/\r?\n/g, '<br/>'));

      const commentHTML = DOMPurify.sanitize(cleaned);

      return(<Box display="flex" onClick={() => handleMessageClick?.(chat)}
      sx={{
        p: 1,
        borderRadius: 1,
        cursor: "pointer",
        bgcolor: chat?.__id === replyToMsg?.__id ? "primary.light" : "transparent",
        borderRight: chat?.__id === replyToMsg?.__id ? "4px solid #1976d2" : "none",
      }}>
        <ListItemAvatar>
          <Avatar
                alt={managers[chat.author]}
                src={undefined}
                sx={{
                  width: 40,
                  height: 40,
                  bgcolor: getColorByLetter(managers[chat.author]?.charAt(0).toLocaleUpperCase()),
                  color: '#fff',
                  fontWeight: 600,
                }}
              >
                {managers[chat.author]?.charAt(0).toLocaleUpperCase()}
              </Avatar>
        </ListItemAvatar>
        <Box>
            <Typography
              variant="body2"
              color="grey.400"
              mb={1}
            >
              {managers[chat.author]},{" "}
              {formatToRussianDateSmart(
                new Date(chat.__createdAt)
              )}{" "}
            </Typography>
        <Box
      display="flex"
      flexDirection="column"
      sx={{
        p: 1.5,
        borderRadius: 2,
        bgcolor: "grey.100",
        maxWidth: "100%",
        mb: 2,
        position: "relative",
        border: "1px solid #e0e0e0",
      }}
    >
      <Box>
      {/* Пересланное сообщение */}
      {replyedMessage && (
        <Box
          onClick={(e) => {
            e.stopPropagation();
            e.preventDefault();
            scrollToMessage(replyedMessage.id);
          }}
          sx={{
            p: 1,
            backgroundColor: "#f0f0f0",
            borderLeft: "4px solid #4caf50",
            mb: 1,
            borderRadius: "6px",
          }}
        >
          <Typography
            variant="subtitle2"
            sx={{ color: "#4caf50", fontWeight: 600 }}
          >
            {replyedMessage.senderId !== '0' ? managers[replyedMessage.author] : 'Я'}
          </Typography>

          {replyedMessage.msg && (
            <Typography
              variant="body2"
              sx={{ color: "text.primary" }}
              dangerouslySetInnerHTML={{
                __html: DOMPurify.sanitize(replyedMessage.msg),
              }}
            />
          )}

          {/* Файлы пересланного */}
          {replyedMessage.files && replyedMessage.files.length > 0 && (
            <Box mt={1}>
              {replyedMessage.files.map((file: any, index: number) => (
                <Button
                  key={index}
                  href={file.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  sx={{ display: "block", fontSize: 13 }}
                  onClick={() => {
                    dispatch(showFilePreview({
                      url: files.find((el) => el.fileId === file.__id).url ?? '',
                      name: file.originalName ?? '',
                      type: '',
                  } ));
                    setSelectedFile({
                      url: files.find((el) => el.fileId === file.__id).url,
                      name: file.originalName,
                      type: '',
                  }); 
                  }
                }
                >
                  📎 {file.name}
                </Button>
              ))}
            </Box>
          )}

          {/* Изображения пересланного */}
          {replyedMessage.images && replyedMessage.images.length > 0 && (
            <ImageList cols={3} rowHeight={100} sx={{ mt: 1 }}>
              {replyedMessage.images.map((img: any, i: any  ) => (
                <ImageListItem key={i}>
                  <img src={img} alt={`img-${i}`} loading="lazy" />
                </ImageListItem>
              ))}
            </ImageList>
          )}
        </Box>
      )}

      {/* Основное сообщение */}
      <Box id={chat.__id}>
        {/* Основной текст */}
        {chat.body && (
          <Typography
            variant="body1"
            sx={{
              whiteSpace: "pre-wrap",
              wordBreak: "break-word",
              mb: chat.files || chat.images ? 1 : 0,
            }}  
            dangerouslySetInnerHTML={{
              __html: DOMPurify.sanitize(chat.body),
            }}
          />
        )}

        {/* Файлы */}
        {chat.files && chat.files.length > 0 && (
          <Box mt={1}>
            {chat.files.map((file: any, index: number) => {
              const url = files?.find((file2) => file2.fileId === file?.__id)?.url;
              const extension = file.__name.split('.').at(-1)?.toLowerCase();
              if (['png', 'jpg', 'jpeg'].includes(extension)) {
                // // console.log(file);
                return (
                  url ? <Box sx={{ position: 'relative', marginRight: 4, mb: 2 }}>
                      <img
                      key={file.fileId}
                      src={url ?? ''} // именно файл, не .url
                      alt="Uploaded image"
                      style={{ maxWidth: '200px', height: 'auto' }}
                      onClick={() => {
                        dispatch(showFilePreview({
                      url: files.find((el) => el.fileId === file.__id).url ?? '',
                      name: file.originalName ?? '',
                      type: '',
                  } ));
                        setSelectedFile({
                          url,
                          name: file.originalName,
                          type: 'img',
                        })
                      }
                    }
                      
                    />
                    {/* <ReplyAllRounded
                      fontSize="medium"
                      sx={{
                        position: 'absolute',
                        right: '-30px',
                        top: '50%',
                        transform: 'translateY(-50%)', // <-- центрируем по вертикали
                        color: "primary.main"
                      }}
                    /> */}
                  </Box> : <p>Файл загружается...</p>
                );
                } else {
                  return(
                  url ? (
                  <Box sx={{ position: 'relative', marginRight: 4, mb: 2 }}>
                    <Button
                      key={file.fileId}
                      variant="outlined"
                      startIcon={<IconDownload />}
                      onClick={() => {
                        dispatch(showFilePreview({
                      url: files.find((el) => el.fileId === file.__id).url ?? '',
                      name: file.originalName ?? '',
                      type: '',
                  } ));
                        setSelectedFile({
                          url: files.find((el) => el.fileId === file.__id).url,
                          name: file.originalName,
                          type: '',
                        })
                      }
                    }
                      sx={{ textTransform: 'none', mt: 1 }}
                    >
                      Скачать файл
                    </Button>
                    {/* <ReplyAllRounded
                    fontSize="medium"
                    sx={{
                      position: 'absolute',
                      right: '-30px',
                      top: '50%',
                      transform: 'translateY(-50%)', // <-- центрируем по вертикали
                      color: "primary.main"
                    }}
                    /> */}
                  </Box>
                  ) : (
                    <p>Файл загружается...</p>
                  )
                )}
            })}
          </Box>
        )}
      </Box>
    </Box>
    </Box>
    </Box>
      </Box>)
    } else if (selectedChat && (chat.senderId !== selectedChat.name && !!chat.messageId)) {
      const replyedMessage = chat.prevComment ? {
        attachment: [],
        author: chat.prevComment.author,
        comments: [],
        createdAt: chat.prevComment.__createdAt,
        id: chat.prevComment.__id,
        msg: chat.prevComment.body,
        senderId: chat.prevComment?.author === clientId ? '0' : selectedChat.name,
        type: "text",
        messageId: chat.messageId,
      } : AllMainMessages[chat.messageId];
      
      safeHtml = DOMPurify.sanitize(cleaned?.replace(/\r?\n/g, '<br/>'));

      const commentHTML = DOMPurify.sanitize(cleaned);

      // // console.log(files);

      return (
        <Box
          key={index + replyedMessage?.createdAt}
          display="flex"
          justifyContent="flex-end"
          onClick={() => handleMessageClick?.(chat)}
          sx={{
            p: 1,
            borderRadius: 1,
            cursor: "pointer",
            bgcolor: chat?.__id === replyToMsg?.__id ? "primary.light" : "transparent",
            borderRight: chat?.__id === replyToMsg?.__id ? "4px solid #1976d2" : "none",
          }}
        >
          <Box display="flex" flexDirection="row-reverse">
            <Box maxWidth="100%">
              <Typography
                variant="body2"
                color="grey.400"
                textAlign="right"
                mb={1}
              >
                {formatToRussianDateSmart(new Date(replyedMessage?.createdAt))}
              </Typography>
      
              <Box
                display="flex"
                flexDirection="column"
                sx={{
                  p: 1.5,
                  borderRadius: 2,
                  bgcolor: "grey.100",
                  maxWidth: "100%",
                  mb: 2,
                  position: "relative",
                  border: "1px solid #e0e0e0",
                }}
              >
                {/* Пересланное сообщение */}
                {replyedMessage && (
                  <Box
                    onClick={(e) => {
                      e.stopPropagation();
                      e.preventDefault();
                      scrollToMessage(replyedMessage.id);
                    }}
                    sx={{
                      p: 1,
                      backgroundColor: "#f0f0f0",
                      borderLeft: "4px solid #4caf50",
                      mb: 1,
                      borderRadius: "6px",
                    }}
                  >
                    <Typography
                      variant="subtitle2"
                      sx={{ color: "#4caf50", fontWeight: 600 }}
                    >
                      {replyedMessage.senderId !== '0' ? managers[replyedMessage.author] : 'Я'}
                    </Typography>
      
                    {replyedMessage.msg && (
                      <Typography
                        variant="body2"
                        sx={{ color: "text.primary" }}
                        dangerouslySetInnerHTML={{
                          __html: DOMPurify.sanitize(replyedMessage.msg),
                        }}
                      />
                    )}
      
                    {replyedMessage.files?.length > 0 && (
                      <Box mt={1}>
                        {replyedMessage.files.map((file: any, index: number) => (
                          <Button
                            key={index}
                            href={file.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            sx={{ display: "block", fontSize: 13 }}
                            onClick={() => {
                            dispatch(showFilePreview({
                      url: files.find((el) => el.fileId === file.__id).url ?? '',
                      name: file.originalName ?? '',
                      type: '',
                  } ));
                              setSelectedFile({
                                url: files.find((el) => el.fileId === file.__id).url,
                                name: file.originalName,
                                type: 'img',
                              })
                            }
                          }
                          >
                            📎 {file.name}
                          </Button>
                        ))}
                      </Box>
                    )}
      
                    {replyedMessage.images?.length > 0 && (
                      <ImageList cols={3} rowHeight={100} sx={{ mt: 1 }}>
                        {replyedMessage.images.map((img: any, i: number) => (
                          <ImageListItem key={i}>
                            <img src={img} alt={`img-${i}`} loading="lazy" />
                          </ImageListItem>
                        ))}
                      </ImageList>
                    )}
                  </Box>
                )}
      
                {/* Основное сообщение */}
                <Box id={chat.__id}>
                  {chat.body && (
                    <Typography
                      variant="body1"
                      sx={{
                        whiteSpace: "pre-wrap",
                        wordBreak: "break-word",
                        mb: chat.files || chat.images ? 1 : 0,
                        textAlign: "left",
                      }}
                      dangerouslySetInnerHTML={{
                        __html: DOMPurify.sanitize(chat.body),
                      }}
                    />
                  )}
      
      {chat.files && chat.files.length > 0 && (
          <Box mt={1}>
            {chat.files.map((file: any, index: number) => {
              const url = files?.find((file2) => file2.fileId === file?.__id)?.url;
              const extension = file.__name.split('.').at(-1)?.toLowerCase();
              if (['png', 'jpg', 'jpeg'].includes(extension)) {
                return (
                  url ? <Box sx={{ position: 'relative', marginRight: 4, mb: 2 }}>
                      <img
                      key={file.fileId}
                      src={url ?? ''} // именно файл, не .url
                      alt="Uploaded image"
                      style={{ maxWidth: '200px', height: 'auto' }}
                      onClick={() => {
                        dispatch(showFilePreview({
                      url: files.find((el) => el.fileId === file.__id).url ?? '',
                      name: file.originalName ?? '',
                      type: '',
                  } ));
                        setSelectedFile({
                          url: files.find((el) => el.fileId === file.__id).url,
                          name: file.originalName,
                          type: 'img',
                        })
                      }
                    }
                      
                    />
                    {/* <ReplyAllRounded
                      fontSize="medium"
                      sx={{
                        position: 'absolute',
                        right: '-30px',
                        top: '50%',
                        transform: 'translateY(-50%)', // <-- центрируем по вертикали
                        color: "primary.main"
                      }}
                    /> */}
                  </Box> : <p>Файл загружается...</p>
                );
                } else {
                  return(
                  url ? (
                  <Box sx={{ position: 'relative', marginRight: 4, mb: 2 }}>
                    <Button
                      key={file.fileId}
                      variant="outlined"
                      startIcon={<IconDownload />}
                      sx={{ textTransform: 'none', mt: 1 }}
                      onClick={() => {
                        dispatch(showFilePreview({
                      url: files.find((el) => el.fileId === file.__id).url ?? '',
                      name: file.originalName ?? '',
                      type: '',
                  } ));
                        setSelectedFile({
                          url: files.find((el) => el.fileId === file.__id).url,
                          name: file.originalName,
                          type: '',
                        })
                      }
                      }
                    >
                      Скачать файл
                    </Button>
                    {/* <ReplyAllRounded
                    fontSize="medium"
                    sx={{
                      position: 'absolute',
                      right: '-30px',
                      top: '50%',
                      transform: 'translateY(-50%)', // <-- центрируем по вертикали
                      color: "primary.main"
                    }}
                    /> */}
                  </Box>
                  ) : (
                    <p>Файл загружается...</p>
                  )
                )}
            })}
          </Box>
        )}
                </Box>
              </Box>
            </Box>
          </Box>
        </Box>
      );      
    } else if (selectedChat && (selectedChat.id === chat.senderId) && !chat.messageId) {
      return(
          <Box display="flex" onClick={() => handleMessageClick?.(chat)}
          sx={{
            p: 1,
            borderRadius: 1,
            cursor: "pointer",
            bgcolor: replyToMsg?.id === chat.id ? "primary.light" : "transparent",
            borderLeft: replyToMsg?.id === chat.id ? "4px solid #1976d2" : "none",
          }}>
            <ListItemAvatar>
              <Avatar
                alt={managers[chat.author]}
                src={undefined}
                sx={{
                  width: 40,
                  height: 40,
                  bgcolor: getColorByLetter(managers[chat.author]?.charAt(0).toLocaleUpperCase()),
                  color: '#fff',
                  fontWeight: 600,
                }}
              >
                {managers[chat.author]?.charAt(0).toLocaleUpperCase()}
              </Avatar>
            </ListItemAvatar>
            <Box>
              <Box>
              {chat.createdAt ? (
                <Typography
                  variant="body2"
                  color="grey.400"
                  mb={1}
                >
                  {managers[chat.author]},{" "}
                  {formatToRussianDateSmart(
                    new Date(chat.createdAt)
                  )}{" "}
                </Typography>
              ) : null}
              {chat.type === "text" ? (
                <Box>
                {chat.msg && <Box
                  id={chat.id}
                  mb={2}
                  sx={{
                    p: 1,
                    backgroundColor: "grey.100",
                    mr: "auto",
                    maxWidth: "320px",
                  }}
                  dangerouslySetInnerHTML={{ __html: safeHtml ?? '<p></p>' }}
                />}
                {files.length > 0 && chat.files?.length > 0 && chat.files.map((file: any) => {
                  const url = files?.find((file2) => file2.fileId === file?.__id)?.url;
                  const extension = file.__name.split('.').at(-1)?.toLowerCase();
                  if (['png', 'jpg', 'jpeg'].includes(extension)) {
                    return url ? (
                      <img
                        key={file.fileId}
                        src={url}
                        alt="Uploaded image"
                        style={{ maxWidth: '200px', height: 'auto', cursor: 'pointer' }}
                        onClick={() => {
                          dispatch(showFilePreview({
                      url: files.find((el) => el.fileId === file.__id).url ?? '',
                      name: file.originalName ?? '',
                      type: '',
                  } ));
                          setSelectedFile({
                            url,
                            name: file.originalName,
                            type: 'img',
                          })
                        }
                      }
                        
                      />
                    ) : (
                      <p key={file.fileId}>Файл загружается...</p>
                    );
                  } else {
                    return <p key={file.fileId}>{file.fileId}</p>;
                  }
                })}
              </Box>
              
              ) : null}
            </Box>
          </Box>
          </Box>
      )
    } else if (selectedChat && (selectedChat.id !== chat.senderId) && !chat.messageId) {
      return(
        <Box key={index + chat.createdAt}>
        {/* Если сообщение не от клиента и без комментария */}
          <Box
            mb={1}
            display="flex"
            alignItems="flex-end"
            flexDirection="row-reverse"
            onClick={() => handleMessageClick?.(chat)}
          sx={{
            p: 1,
            borderRadius: 1,
            cursor: "pointer",
            bgcolor: replyToMsg?.id === chat.id ? "primary.light" : "transparent",
            borderRight: replyToMsg?.id === chat.id ? "4px solid #1976d2" : "none",
          }}>
          
            <Box
              alignItems="flex-end"
              display="flex"
              flexDirection={"column"}
            >
              {chat.createdAt ? (
                <Typography
                  variant="body2"
                  color="grey.400"
                  mb={1}
                >
                  {formatToRussianDateSmart(
                    new Date(chat.createdAt)
                  )}{" "}
                </Typography>
              ) : null}
              {chat.type === "text" ? (
                <Box>
                  <Box>
                  {chat.msg && <Box
                    id={chat.id}
                    mb={1}
                    sx={{
                      p: 1,
                      backgroundColor: "primary.light",
                      ml: "auto",
                      maxWidth: "320px",
                    }}
                    dangerouslySetInnerHTML={{ __html: safeHtml ?? '<p></p>'}}
                  >
                  </Box>} 
                  {files.length > 0 && chat.files?.length > 0 && chat.files.map((file: any) => {
                  const url = files?.find((file2) => file2.fileId === file?.__id)?.url;
                  const extension = file.__name.split('.').at(-1)?.toLowerCase();

                  if (['png', 'jpg', 'jpeg'].includes(extension)) {
                    return (
                      url ? <img
                        key={file.fileId}
                        src={url ?? ''} // именно файл, не .url
                        alt="Uploaded image"
                        style={{ maxWidth: '200px', height: 'auto' }}
                        onClick={() => {
                          dispatch(showFilePreview({
                      url: files.find((el) => el.fileId === file.__id).url ?? '',
                      name: file.originalName ?? '',
                      type: '',
                  } ));
                          setSelectedFile({
                            url,
                            name: file.originalName,
                            type: 'img',
                          })
                        }
                      }
                        
                      /> : <p>Файл загружается...</p>
                    );
                  } else {
                    return(
                    url ? (
                      <>
                      <Typography>{file.originalName}</Typography>
                      <Button
                        key={file.fileId}
                        variant="outlined"
                        startIcon={<IconDownload />}
                        onClick={() => {
                          dispatch(showFilePreview({
                      url: files.find((el) => el.fileId === file.__id).url ?? '',
                      name: file.originalName ?? '',
                      type: '',
                  } ));
                          setSelectedFile({
                            url: files.find((el) => el.fileId === file.__id).url,
                            name: file.originalName,
                            type: '',
                          })
                        }
                      }
                        sx={{ textTransform: 'none', mt: 1 }}
                      >
                        Скачать файл
                      </Button>
                    </>
                    ) : (
                      <p>Файл загружается...</p>
                    )
                  )}
                })}
                </Box>
                </Box>
              ) : null}
            </Box>
          </Box>
      </Box>
      )
    } else {
      return(<p>Сообщение загружается...</p>)
    }
  }
  

  return selectedChat && Object.keys(managers)?.length > 0 ? (
    <SimpleBar>
      <Box sx={{display: 'flex', flexWrap: 'wrap'}}>
        {selectedChat ? (
          <Box width={'100%'}> 
            {/* ------------------------------------------- */}
            {/* Header Part */}
            {/* ------------------------------------------- */}
            <Box>
            {open &&
                <><Box display="flex" alignItems="center" p={2}>
              <Box
                    sx={{
                      display: { xs: "block", md: "block", lg: "block" },
                      mr: "10px",
                    }}
                  >
                  </Box>
                <ListItem key={selectedChat.name} dense disableGutters>
                  <ListItemAvatar>
                    <Badge
                      color={
                        selectedChat.status === "online"
                          ? "success"
                          : selectedChat.status === "busy"
                            ? "error"
                            : selectedChat.status === "away"
                              ? "warning"
                              : "secondary"
                      }
                      variant="dot"
                      anchorOrigin={{
                        vertical: "bottom",
                        horizontal: "right",
                      }}
                      overlap="circular"
                    >
                      <Avatar alt={selectedChat.name} src={selectedChat.thumb} sx={{ width: 40, height: 40 }} />
                    </Badge>
                  </ListItemAvatar>
                  <ListItemText
                    primary={
                      <Typography variant="h5" fontWeight={600}>Заказ №{selectedChat.name}</Typography>
                    }
                    secondary={selectedChat.status}
                  />
                </ListItem>
              </Box></>}
              <Divider />
            </Box>
            {/* ------------------------------------------- */}
            {/* Chat Content */}
            {/* ------------------------------------------- */}

            <Box sx={{display: 'flex', width: 'auto', overflow: 'auto'}} ref={mainBoxRef}>
              {/* ------------------------------------------- */}
              {/* Chat msges */}
              {/* ------------------------------------------- */}

              <Box>
                <Box
                  sx={{
    overflow: "auto",
    maxHeight: "600px",
    height: open ? '600px' : 'auto',
    width:
      lgUp ? 
        !open ? 
        mainBoxRef && inBoxRef &&
        ((mainBoxRef.current?.clientWidth || 0) -
          (inBoxRef.current?.clientWidth || 0)) > 300
          ? `${(mainBoxRef.current?.clientWidth || 0) -
              (inBoxRef.current?.clientWidth || 0)}px`
          : "300px" 
        : "31vw" 
      : open ? window.innerWidth - 90 : window.innerWidth - 150 ,

    // <-- Вот сюда вставляем
    scrollbarWidth: 'none', // Firefox
    '&::-webkit-scrollbar': {
      display: 'none', // Chrome/Safari
    },
  }}
                >
                  <Box p={3}>
                    {/* Начинается основная логика */}
                    {(open ? sortedMessages : sortedMessages.slice(sortedMessages.length - 4  ))?.map(getMessages)}
                    <div ref={messagesEndRef} />
                  </Box>
                </Box>
              </Box>

              {/* ------------------------------------------- */}
              {/* Chat right sidebar Content */}
              {/* ------------------------------------------- */}
              {open ? (
                <Box display="flex" flexShrink="0px" ref={inBoxRef}>
                  <ChatInsideSidebar
                    isInSidebar={lgUp ? open : open}
                    chat={selectedChat}
                  />
                </Box>
              ) : (
                ""
              )}
            </Box>
          </Box>
          
        ) : (
          <Box display="flex" alignItems="center" p={2} pb={1} pt={1}>
            {/* ------------------------------------------- */}
            {/* if No Chat Content */}
            {/* ------------------------------------------- */}
            <Box
              sx={{
                display: { xs: "flex", md: "flex", lg: "flex" },  
                mr: "10px",
              }}
            >
              <IconMenu2 stroke={1.5} />
            </Box>
            <Typography variant="h4">Выбрать чат</Typography>
          </Box>
        )}
      </Box>

    </SimpleBar>
  ): <></>;
};

export default React.memo(ChatContent);

