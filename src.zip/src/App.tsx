import { CssBaseline, ThemeProvider } from '@mui/material';
import { ThemeSettings } from './theme/Theme';
import RTL from './layouts/full/shared/customizer/RTL';
import { BrowserRouter, RouterProvider, useLocation, useNavigate } from 'react-router';
import router from './routes/Router';
import { CustomizerContext } from 'src/context/CustomizerContext';
import { useContext, useEffect } from 'react';
import PushManagerComponent from './utils/pushSubscribe';
import AppRoutes from './routes/Router';
import api from './store/api';
import { useAppDispatch } from './store/hooks';
import { setClient } from './store/slices/authSlice';
import { getContragent, savePushSubscription } from './store/middleware/thunks';
import FilePreviewDialog from './components/apps/popUpFiles/FileDialog';
import { connectWebSocket, isWebSocketConnected } from './websocket';
import NotificationPromptModal from './components/notifications/NotificationPromptModal';


function App() {

  const theme = ThemeSettings();
  const { activeDir } = useContext(CustomizerContext);
  const dispatch = useAppDispatch();


  useEffect(() => {
    connectWebSocket();

    if (typeof Notification !== 'undefined' && Notification.permission === 'default') {
      Notification.requestPermission().catch((e) =>
        console.warn('❗Ошибка при запросе разрешения на уведомления:', e)
      );
    }

    const fetchUserData = async () => {
      const response = await api.get('/getUserData');
      console.log(response);
      dispatch(savePushSubscription({ email: response.data.email }));
      dispatch(setClient(response.data));
    }
  
    fetchUserData();

    dispatch(getContragent());
  }, []);  

  return (
    <ThemeProvider theme={theme}>
    <PushManagerComponent />
    <RTL direction={activeDir}>
      <CssBaseline />
      <BrowserRouter>
        <AppRoutes />
        <FilePreviewDialog />
      </BrowserRouter>
    </RTL>
   <NotificationPromptModal/>
  </ThemeProvider>
  );
}

export default App;
