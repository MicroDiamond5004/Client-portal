import express from 'express';
import webpush from 'web-push';
import bodyParser from 'body-parser';
import cors from 'cors';
import { ELMATicket, MessageType, UserData } from './data/types';
import { getUserSubscriptions, loadUserData, saveUserData, saveUserSubscription } from './data/storage';
import path from 'path';
import { readdirSync } from 'fs';
import fs from 'fs';
import axios from 'axios';
import { error } from 'console';
import multer from 'multer';
import FormData from 'form-data';
import { v4 as uuidv4 } from 'uuid';
import rateLimit from "express-rate-limit";
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';

dotenv.config();

const AUTH_DATA_PATH = "./src/data/auth/authData.json";

function readAuthData() {
  const data = fs.readFileSync(AUTH_DATA_PATH, "utf-8");
  return JSON.parse(data);
}

// Пример того, как создается и проверяется токен
const generateToken = (user: any) => {
  // Вы можете добавить любые данные, которые хотите хранить в токене
  const payload = { id: user.id, username: user.auth_login };
  
  // Создаем токен с таймаутом на 1 час (можно изменить)
  return jwt.sign(payload, process.env.JWT_SECRET as string, { expiresIn: '24h' });
};

const authenticateToken = (req: any, res: any, next: any) => {
  // Извлекаем токен из заголовков запроса
  const token = req.header('Authorization')?.replace('Bearer ', '');

  if (!token) {
    return res.status(401).json({ error: "Токен не предоставлен" });
  }

  // Проверка токена
  jwt.verify(token, process.env.JWT_SECRET as string, (err: any, user: any) => {
    if (err) {
      return res.status(403).json({ error: "Токен не действителен" });
    }

    // Если токен валиден, сохраняем информацию о пользователе в запрос
    req.user = user;

    const allowedUsers = readAuthData();

    const authUser = allowedUsers.find(
      (curentUser: any) => curentUser.auth_login === user.username
    );

    req.clientId = authUser?.klient_id ?? '';

    req.clientName = authUser?.klient_name ?? 'Клиент';

    req.externalToken = 'Bearer eyJhbGciOiJSUzUxMiIsInR5cCI6IkpXVCJ9.eyJjb21wYW55IjoiaGVhZCIsInVzZXJJZCI6IjFlMWFjZWU2LThiZTYtNDQ5ZC04ZWViLWUxYzY2ODRkMTEzOSIsIm93bmVyIjpmYWxzZSwiaXNQb3J0YWwiOmZhbHNlLCJzZXNzaW9uSWQiOiI0NTY3YTI3ZS05ZTcwLTU0OWYtYmQyMy0xMzQ5NDNjZjA5NTkiLCJwcml2aWxlZ2VzIjpbXSwibmVlZENoYW5nZVBhc3N3b3JkIjpmYWxzZSwiY3JlYXRlZEF0IjoxNzQ1NTE5ODUwLCJpc3MiOiJhcGkiLCJleHAiOjE3NDc5Mzk2ODksImlhdCI6MTc0NTUyMDM2OX0.LQJMHxpXRxzlkoT2sc7PwjRjr1WCBjn-TbgPK406KXBTRUpJ8Pk8Tzm9OhSLUUU_Q5I98Qrh7bHVPhymhkYwF7wNIrqH9hzPe_0CbKokkFwViq3O9pmNzuryVl9BtKis7pEfayO8TjaMLpeZVfBWhUZt11K_40E7fV9qg8FN1Rg';
    next();
  });
};

const upload = multer();

const app = express();
app.use(cors());
app.use(bodyParser.json());

// 🔑 Конфигурация VAPID-ключей
const VAPID_KEYS = {
  publicKey: 'BIyUd7eREfLOnyukFMR9DuezE8uXAnOwp_-Rr7YxIX-RIxm2IRW6uJ90vB1OBn51o0rGAf8k4SQGR-ZfuutHmiE',
  privateKey: 'WM4lBtcHCBrKFaiZiOLF39NbMjML-H3VaDNXkCQBFmg', // 👈 НЕ выкладывай этот ключ на клиент!
};

const TOKEN = 'Bearer a515732b-4549-4634-b626-ce4362fb10bc';

// Ограничение: не более 3 запросов с одного IP за 2 минуты
const loginLimiter = rateLimit({
  windowMs: 2 * 60 * 1000,
  max: 3,
  message: {
    error: "Слишком много попыток входа. Попробуйте позже.",
  },
});

// Это "единый логин", который реально используется при обращении к внешнему API
const FIXED_CREDENTIALS = {
  auth_login: "dev_9@lead.aero",
  password: "*cJ85gXS7Sfd",
  remember: false,
};

// app.post("/api/login", loginLimiter, async (req: any, res: any) => {
//   const { login: auth_login, password } = req.body;

//   if (!auth_login || !password) {
//     return res.status(400).json({ error: "auth_login и password обязательны" });
//   }

//   try {
//     const allowedUsers = await readAuthData();
//     const isAllowed = allowedUsers.some(
//       (user: any) => user.auth_login === auth_login && user.password === password
//     );

//     if (!isAllowed) {
//       return res.status(403).json({ error: "Доступ запрещён" });
//     }

//     // Если пользователь разрешён — делаем реальный логин
//     const loginUrl = "https://portal.dev.lead.aero/guard/login";

//     const loginResponse = await fetch(loginUrl, {
//       method: "POST",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify(FIXED_CREDENTIALS),
//     });

//     if (!loginResponse.ok) {
//       return res.status(502).json({ error: "Ошибка авторизации на внешнем сервисе" });
//     }

//     const loginData = await loginResponse.json();
//     const token = loginData.token;

//     if (!token) {
//       return res.status(500).json({ error: "Не удалось получить токен" });
//     }

//     res.json({ token });
//   } catch (err) {
//     console.error("Ошибка в /api/login:", err);
//     res.status(500).json({ error: "Внутренняя ошибка сервера" });
//   }
// });

app.get("/api/user", authenticateToken, async (req: any, res: any) => {
  try {
    // Доступ к данным пользователя через req.user (они были получены из токена)
    const user = req.user; // Это будет объект, который мы передаем в payload токена

    // Здесь можно найти пользователя в базе данных, если нужно
    // const userData = await getUserData(user.id);

    res.json({ message: "Успешный доступ к данным пользователя", user });
  } catch (err) {
    res.status(500).json({ error: "Ошибка при получении данных" });
  }
});

app.post("/api/refresh-token", authenticateToken, (req: any, res: any) => {
  try {
    const { user } = req;
    
    // Создаем новый токен с теми же данными, что и старый
    const newToken = generateToken(user);
    
    res.json({ token: newToken });
  } catch (err) {
    res.status(500).json({ error: "Ошибка обновления токена" });
  }
});


app.post("/api/login", loginLimiter, async (req: any, res: any) => {
  const { login: auth_login, password } = req.body;

  if (!auth_login || !password) {
    return res.status(400).json({ error: "auth_login и password обязательны" });
  }

  try {

    const allowedUsers = readAuthData();
    const isAllowed = allowedUsers.filter(
      (user: any) => user.auth_login === auth_login && user.password === password 
    );

    const clientName = isAllowed[0]?.klient_name;

    if (!isAllowed) {
      return res.status(403).json({ error: "Доступ запрещён" });
    }

    // Создаем токен после успешной авторизации
    const token = generateToken({ auth_login, clientName });

    // Отправляем токен в ответ
    res.json({ token, clientName });
  } catch (err) {
    console.error("Ошибка в /api/login:", err);
    res.status(500).json({ error: "Внутренняя ошибка сервера" });
  }
});

const uploadFilesAndGetIds = async (files: Express.Multer.File[], token: string): Promise<string[]> => {
  if (!files || files.length === 0) return [];

  // Получаем список директорий
  const { data: listData } = await axios.get(
    'https://portal.dev.lead.aero/pub/v1/disk/directory/list',
    {
      params: { query: JSON.stringify({}) },
      headers: { Authorization: token },
    }
  );

  const targetDir = listData?.result?.result?.[0];
  if (!targetDir) {
    throw new Error('Нет доступных директорий для загрузки');
  }

  const directoryId = targetDir.__id;
  console.log('🎯 Загрузка в директорию:', directoryId);

  const uploadedFileIds = await Promise.all(
    files.map(async (file) => {
      const hash = uuidv4();

      if (file.buffer.length !== file.size) {
        throw new Error(`Неверный размер файла ${file.originalname}`);
      }

      const form = new FormData();
      form.append('file', file.buffer, {
        filename: file.originalname,
        contentType: file.mimetype,
        knownLength: file.buffer.length,
      });

      const contentLength = await new Promise<number>((resolve, reject) => {
        form.getLength((err, length) => {
          if (err) reject(err);
          else resolve(length);
        });
      });

      const headers = {
        ...form.getHeaders(),
        Authorization: token,
        'Content-Length': contentLength,
      };

      console.log('⬆️ Загружаем файл:', file.originalname);
      console.log('📦 Content-Length:', contentLength);

      const uploadRes = await axios.post(
        `https://portal.dev.lead.aero/pub/v1/disk/directory/${directoryId}/upload`,
        form,
        {
          params: { hash },
          headers,
          maxBodyLength: Infinity,
          maxContentLength: Infinity,
        }
      );

      console.log('✅ Успешно загружен:', uploadRes.data.file.name);
      return uploadRes.data.file.__id;
    })
  );

  return uploadedFileIds;
};

webpush.setVapidDetails(
  'mailto:test@example.com',
  VAPID_KEYS.publicKey,
  VAPID_KEYS.privateKey
);

// {
//   "context": {
//     "kontakt": [
//       "0194fa07-f526-7c98-873d-5f0d7547168a"
//     ],
//     "zapros": "example"
//   }
// }

// Создание нового заказа
app.post('/api/orders/new', authenticateToken, upload.array('imgs'), async (req: any, res: any) => {
  const user = req.user;
  // console.log(user);
  try {
    const files = req.files;
    const zapros = req.body.zapros || '';
    const uploadedFileIds = await uploadFilesAndGetIds(files, TOKEN);

    const contextPayload: any = {
      kontakt: ['0194fa07-f526-7c98-873d-5f0d7547168a'],
      zapros_klienta: zapros,
    };

    if (uploadedFileIds.length > 0) {
      contextPayload.prilozhenie_k_zaprosu = uploadedFileIds;
    }

    const elmaResponse = await axios.post(
      'https://portal.dev.lead.aero/pub/v1/bpm/template/work_orders.OrdersNew/glavnyi_bp_copy_copy/run',
      JSON.stringify({ context: contextPayload }),
      {
        headers: {
          'Authorization': 'Bearer a515732b-4549-4634-b626-ce4362fb10bc',
          'Content-Type': 'application/json'
        }
      }
    );

    res.json({
      message: 'Заявка отправлена',
      elmaResponse: elmaResponse.data,
      fileIds: uploadedFileIds,
    });

  } catch (err: any) {
    console.error('❌ Ошибка:', err.response?.data || err.message);
    res.status(500).json({ error: 'Ошибка при обработке запроса' });
  }
});


// 🎯 Роут для приёма подписки и отправки уведомления
app.post('/api/send-notification', async (req, res) => {
  const { subscription, message, title } = req.body;

  const payload = JSON.stringify({
    title: title || '🚀 Push из backend!',
    body: message || 'Нет текста в сообщении',
  });

  try {
    // console.log(subscription);
    await webpush.sendNotification(subscription, payload);
    // console.log('✅ Уведомление отправлено!');
    res.status(201).json({ success: true });
  } catch (error) {
    console.error('❌ Ошибка отправки уведомления:', error);
    res.status(500).json({ error: 'Ошибка отправки уведомления' });
  }
});

app.get('/api/proxy/:userId/:id', authenticateToken, async (req: any, res: any) => {
  const user = req.user;
  const token = req.externalToken;
  const clientId = req.clientId;
  // console.log(user);
  const { id, userId } = req.params;

  if (!userId || !id || !clientId) {
    return res.status(400).json({ error: 'Не указан userId или id заказа' });
  }  

  try {
    // Получаем последние сообщения с ELMA
    const response = await axios.get(`https://portal.dev.lead.aero/api/feed/targets/work_orders/OrdersNew/${id}/messages`, {
      params: {
        limit: 100000,
        offset: 0,
      },
      headers: {
        'Authorization': token,
        'Accept': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
        'Origin': 'https://portal.dev.lead.aero',
        'Referer': 'https://portal.dev.lead.aero/'
      }
    });

    // console.log(response.statusText);

    if (response.statusText !== 'OK') {
      return res.status(500).json({ error: 'Не удалось получить сообщения от ELMA' });
    }

    const elmaData = response.data;
    const elmaMessages = Array.isArray(elmaData) ? elmaData : elmaData?.result || [];

    // console.log(userId);

    // Загружаем локальные данные пользователя
    const userData = loadUserData(clientId);
    const savedMessages = userData?.messages || [];

    // Выявляем новые сообщения (сравниваем по ID или тексту)
    const savedIds = new Set(savedMessages.map((msg: any) => msg.__id));
    const newMessages = elmaMessages.filter((msg: any) => !savedIds.has(msg.__id));

    console.log(newMessages)

    if (newMessages.length > 0) {
      // Добавляем только новые сообщения
      userData.messages.push(...newMessages);
      if (userId && userData) {
        saveUserData(clientId, userData);
      }
    }

    res.json({
      messages: elmaMessages,
      newMessages
    });

  } catch (error) {
    console.error('Ошибка получения сообщений:', error);
    res.status(500).json({ error: 'Ошибка сервера при получении сообщений' });
  }
});

app.post('/api/proxy/send/:id', authenticateToken, async (req: any, res: any) => {
  const user = req.user;
  const token = req.externalToken;
  const clientName = req.clientName;

  // console.log(user);
  const { id } = req.params;
  const { userId, orderNumber, ...messagePayload } = req.body;

  console.log(token);

  try {
    const response = await fetch(`https://portal.dev.lead.aero/api/feed/targets/work_orders/OrdersNew/${id}/messages`, {
      method: 'PUT',
      headers: {
        'Authorization': token,
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'User-Agent': 'Mozilla/5.0',
        'Origin': 'https://portal.dev.lead.aero',
        'Referer': 'https://portal.dev.lead.aero/'
      },
      body: JSON.stringify({
        ...messagePayload,
        body: `<p><h3>Сообщение от ${clientName}:</h3>${messagePayload?.body}</p>`
      })
    });

    console.log(await response?.json());

    const responseAllChannels = await fetch(`https://portal.dev.lead.aero/api/feed/channels/`, {
      method: 'GET',
      headers: {
        'Authorization': token,
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'User-Agent': 'Mozilla/5.0',
        'Origin': 'https://portal.dev.lead.aero',
        'Referer': 'https://portal.dev.lead.aero/messages/channels',
        'X-Requested-With': 'XMLHttpRequest',
        'X-Timezone': 'Europe/Moscow',
        'X-EQL-Timezone': 'Europe/Moscow',
        'X-Language': 'ru-RU'
      }
    });

    const AllChannels = await responseAllChannels?.json();

    const isInChannels = AllChannels?.find((channel: any) => channel?.name?.split('№')[1]?.trim() === orderNumber);

    let channelId = isInChannels?.__id;

    // Создать новый канал в общей elma
    if (!isInChannels || (isInChannels == null)) {
      const response2 = await fetch(`https://portal.dev.lead.aero/api/feed/channels/`, {
        method: 'PUT',
        headers: {
          'Authorization': token,
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'User-Agent': 'Mozilla/5.0',
          'Origin': 'https://portal.dev.lead.aero',
          'Referer': 'https://portal.dev.lead.aero/messages/channels',
          'X-Requested-With': 'XMLHttpRequest',
          'X-Timezone': 'Europe/Moscow',
          'X-EQL-Timezone': 'Europe/Moscow',
          'X-Language': 'ru-RU'
        },
        body: JSON.stringify({
            "author": "c566297b-2f3c-40b5-a27e-7d9f30aae080",
            name: `Заказ №${orderNumber}`,
            members: [], // или [userId], если поле поддерживается
            accessRights: "author"
          })
      });
  
      let request2;
      const contentType = response2.headers.get('Content-Type');

      if (contentType && contentType.includes('application/json')) {
        request2 = await response2.json();
      } else {
        const text = await response2.text();
        console.error("Ошибка при создании канала:", text);
        throw new Error("Сервер вернул не-JSON");
      }

      const raw = await response2.text();
      console.log("RAW RESPONSE:", raw);


      channelId = request2.__id;

      // Присвоить автора конкретному каналу
      const response3 = await fetch(`https://portal.dev.lead.aero/api/feed/channels/${channelId}/members`, {
        method: 'POST',
        headers: {
          'Authorization': token,
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'User-Agent': 'Mozilla/5.0',
          'Origin': 'https://portal.dev.lead.aero',
          'Referer': 'https://portal.dev.lead.aero/messages/channels',
          'X-Requested-With': 'XMLHttpRequest',
          'X-Timezone': 'Europe/Moscow',
          'X-EQL-Timezone': 'Europe/Moscow',
          'X-Language': 'ru-RU'
        },
        body: JSON.stringify([{
          id: "543e820c-e836-45f0-b177-057a584463b7", 
          type: "user", 
          accessRights: "author"
        }])
      });
    }

    // Добавляем сообщение в канал заказа
    const responseChanelMessage = await fetch(`https://portal.dev.lead.aero/api/feed/messages`, {
      method: 'PUT',
      headers: {
        'Authorization': token,
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'User-Agent': 'Mozilla/5.0',
        'Origin': 'https://portal.dev.lead.aero',
        'Referer': `https://portal.dev.lead.aero/channels/${channelId}`
      },
      body: JSON.stringify(
        {
          ...messagePayload,
          title: "Сообщение из внешнего портала",
          target: {
            id: channelId
          }
        })
    });


    // console.log(await responseChanelMessage.json());
    // https://portal.dev.lead.aero/api/feed/channels/067e0ad3-e929-4f28-9ff7-9d2a89b5203a

    

    // body: JSON.stringify({
      // userId: '543e820c-e836-45f0-b177-057a584463b7',
      // body: `<p>${text}</p>`,
      // mentionIds: [],
      // files: []
  // })

    const text = await response.text();
    let result = null;

    if (text) {
      try {
        result = JSON.parse(text);
      } catch (e) {
        console.warn('Ответ не JSON, но есть текст:', text);
      }
    }

    // 💾 Сохраняем сообщение локально
    if (userId && result) {
      const userData = loadUserData(userId);

      // Предполагаем, что result — это сообщение, иначе можно вынести messagePayload
      userData.messages.push(result);

      saveUserData(userId, userData);
    }

    res.status(response.status).json(result || { status: 'ok' });

  } catch (error) {
    console.error('Ошибка запроса:', error);
    if (!res.headersSent) {
      res.status(500).json({ error: 'Ошибка при отправке сообщения' });
    }
  }
});

app.post('/api/save-subscription/:userId', (req: any, res: any) => {
  const { userId } = req.params;
  const subscription = req.body;

  if (!subscription || !subscription.endpoint) {
    return res.status(400).json({ error: 'Некорректная подписка' });
  }

  saveUserSubscription(userId, subscription);
  res.status(201).json({ success: true });
});

app.get('/api/user/:userId/orders', authenticateToken, async (req: any, res: any) => {
  const { userId } = req.params;

  const clientId = req.clientId;

  try {
    const localData = loadUserData(clientId);

    // Если уже есть сохранённые заказы — сразу возвращаем

    // Иначе идем в ELMA365
    const elmaResponse = await axios.post(
      'https://portal.dev.lead.aero/pub/v1/app/work_orders/OrdersNew/list',
      {
        "active": true,
        "fields": {
          "*": true
        },
        "filter": {
          "tf": {
            "fio2": [
              `${clientId}`
            ]
          }
        } 
      },
      {
        params: {
          limit: 100000000,
          offset: 0,
        },
        headers: {
          'Authorization': 'Bearer a515732b-4549-4634-b626-ce4362fb10bc',
          'Content-Type': 'application/json'
        }
      }
    );
    

    if (localData?.orders?.length === elmaResponse.data?.result?.result?.length) {
      return res.json({result: {result: localData.orders, total: localData.orders.length}, error: '', success: true});
    }

    const fetchedOrders = elmaResponse.data || [];

    // Сохраняем новые заказы
    const newData = { orders: fetchedOrders, messages: localData.messages };
    saveUserData(clientId, newData as UserData);

    res.json(fetchedOrders);
  } catch (err: any) {
    console.error('Ошибка при получении заказов из ELMA365:', err.response?.data || err.message);
    res.status(500).json({ error: 'Не удалось получить заказы из ELMA365' });
  }
});


// async function pollNewMessages() {
//   try {
//     const userFiles = readdirSync(path.join(__dirname, 'data', 'user'));

//   for (const file of userFiles) {
//     const userId = file.replace('.json', '');
//     const user = loadUserData(userId);
//     if (!user || !user.messages) continue;

//     const subscriptions = getUserSubscriptions(userId);

//     const orderId = '0';

//     for (const currentMessage of user.messages) {
//       if (!currentMessage.__id) continue;
//       try {
//         const response = await axios.get(
//           `https://portal.dev.lead.aero/api/feed/targets/work_orders/OrdersNew/${currentMessage.target?.id}/messages`,
//           {
//             params: {
//               limit: 100000,
//               offset: 0,
//             },
//             headers: {
//               'Authorization': token,
//               'Content-Type': 'application/json',
//               'Accept': 'application/json',
//               'User-Agent': 'Mozilla/5.0',
//               'Origin': 'https://portal.dev.lead.aero',
//               'Referer': 'https://portal.dev.lead.aero/'
//             },
//           }
//         );
  
//         const { result: messages} = response.data;
//         if (!Array.isArray(messages) || messages.length === 0) continue;

//         const allMessages = user.messages.filter((msg: any) => msg.target?.id === currentMessage.target?.id)

//         if (allMessages.length < messages?.length) console.log(true);
//         console.log(allMessages.length, messages?.length, currentMessage.target?.id);
  
//         while (allMessages.length < messages?.length) {
//           const newMessage = messages[allMessages.length]

//           // console.log(newMessage);
  
//           const payload = JSON.stringify({
//             title: `Новое сообщение по заказу ${orderId ?? '0'}`,
//             body: newMessage.body || 'Новое сообщение',
//           });
  
//           allMessages.push(newMessage);
//           user.messages.push(newMessage);
  
//           for (const sub of subscriptions) {
//             try {
//               await webpush.sendNotification(sub, payload);
//             } catch (err: any) {
//               console.warn('❌ Ошибка отправки пуша:', err.statusCode, err.body);
          
//               if (err.statusCode === 410 || err.statusCode === 404) {
//                 console.log('🗑 Удаляем просроченную подписку...');
//                 // Удалим подписку из файла
//                 const userSubscriptions = getUserSubscriptions(userId);
//                 const updatedSubs = userSubscriptions.filter(s => s.endpoint !== sub.endpoint);
//                 saveUserSubscription(userId, updatedSubs);
//               }
//             }
//           }
//         }
//       } catch (e) {
//         console.warn(`⚠ Ошибка при получении сообщений по заказу ${orderId}`, e);
//       }
//     } 
    

//     saveUserData(userId, user);
//     }
//   } catch (error) {
//     console.error("❌ Ошибка при опросе:", error);
//   } finally {
//     // Ждём 5 секунд после выполнения
//     setTimeout(pollNewMessages, 5000);
//   }
// }

// Запуск первого вызова
// pollNewMessages();

const PORT = 3001;

app.listen(PORT, () => {
  console.log(`🚀 Сервер запущен на http://localhost:${PORT}`);
});
