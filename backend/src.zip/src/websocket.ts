import { WebSocketServer } from 'ws';

let wss: any;

export function initWebSocket(port: number) {
  wss = new WebSocketServer({ port });
  wss.on('connection', (socket: any) => {
    console.log('Клиент подключился');
    socket.on('close', () => console.log('Клиент отключился'));
  });
  console.log(`WebSocket listening on ws://localhost:${port}`);

    wss.on('connection', (ws: any) => {
        ws.on('message', (data: any) => {
            const msg = JSON.parse(data.toString());
            console.log('Получено сообщение от клиента:', msg);

            // Можешь отправить ответ:
            ws.send(JSON.stringify({ type: 'pong', message: 'Принято!' }));
        });
    });
}


export function broadcast(data: any) {
  if (!wss) return;
  const message = JSON.stringify(data);
  wss.clients.forEach((client: any) => {
    if (client.readyState === 1) {
      client.send(message);
    }
  });
}
