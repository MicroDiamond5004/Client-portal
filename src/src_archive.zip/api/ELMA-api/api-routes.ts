export const ApiRoutes = {
    INSTANCE: 'template/work_orders.OrdersNew/glavnyi_bp_copy/run',
    TICKETS: '/app/work_orders/OrdersNew/list',
    BD_ZAKAZA: '/app/work_orders/bd_zakaza/list',
}